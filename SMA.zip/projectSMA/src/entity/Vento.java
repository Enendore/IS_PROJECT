package entity;

import java.util.Date;

/**
 * 
 * Dichiarazione della Classe Vento.
 * 
 * @author L. Arena, F. Caltabiano, V. D'Ambrosio, B. De Carlo
 *
 */

public class Vento extends Sensore{


	String dir_vel;
	Date data;
	int ora;
	int minuti;

	//Costruttori

	/**
	 * 
	 * Costruttore di Default della Classe Vento.
	 * 
	 */

	public Vento () {

		super ();
		dir_vel="";
		data = new Date ();
		ora = 0;
		minuti = 0;


	}

	/**
	 * 
	 * Costruttore della Classe Vento.
	 * 
	 * @param identificativo				ID del Sensore.
	 * @param marca							Marca del Sensore (Il Brand).
	 * @param tipo							Tipologia di Specializzazione del Sensore.
	 * @param idLocalita					ID della Localita' in cui il Sensore � collocato.
	 * @param status						Stato del sensore.
	 * @param dir_vel						Valore del Dato contenuto nel sensore. Direzione e Velocita' del Vento.
	 * @param data							Data attuale.
	 * @param ora							Ora attuale.
	 * @param minuti						Minuti attuali.
	 */

	public Vento (int identificativo, String marca, int tipo, int idLocalita,	boolean status, String dir_vel, Date data, int ora, int minuti) {

		super (identificativo, marca, tipo, idLocalita, status);
		this.dir_vel = dir_vel;
		this.data = (Date) data.clone();
		this.ora = ora;
		this.minuti = minuti;

	}


	//Getters and Setters

	/**
	 * 
	 * Permette di ottenere il valore Rilevato dal Sensore
	 * 
	 * @return								Ritorna il valore contenuto nel sensore. Direzione e Velocita' del Vento.
	 * 
	 */

	public String getDir_vel() {
		return dir_vel;
	}

	/**
	 * 
	 * Salva all'interno del Sensore il Valore.
	 * 
	 * @param dir_vel						Valore relativo alla Direzione e alla Velocita' del Vento.			
	 * 
	 */
	
	public void setDir_vel(String dir_vel) {
		this.dir_vel = dir_vel;
	}

	/**
	 * 
	 * Restituisce la Data a cui il Sensore fa Riferimento.
	 * 
	 * @return								Restituisce la Data a cui il Sensore fa Riferimento.
	 * 
	 */
	
	public Date getData() {
		return data;
	}

	/**
	 * 
	 * Permette di Settare il campo Data.
	 * 
	 * @param data							Data da inserire.
	 * 
	 */

	public void setData(Date data) {
		this.data = data;
	}

	/**
	 * 
	 * Restituisce l'Ora a cui il Sensore fa riferimento.
	 * 
	 * @return								Restituisce l'Ora a cui il Sensore fa riferimento.
	 * 
	 */

	public int getOra() {
		return ora;
	}

	/**
	 * 
	 * Permette di Settare il campo Ora.
	 * 
	 * @param ora							Ora da inserire.
	 * 
	 */

	public void setOra(int ora) {
		this.ora = ora;
	}

	/**
	 * 
	 * Restituisce i Minuti a cui il Sensore fa riferimento.
	 * 
	 * @return								Restituisce i Minuti a cui il Sensore fa riferimento.
	 * 
	 */

	public int getMinuti() {
		return minuti;
	}

	/**
	 * 
	 * Permette di Settare il campo Minuti.
	 * 
	 * @param minuti						Minuti da Inserire.
	 * 
	 */

	public void setMinuti(int minuti) {
		this.minuti = minuti;
	}


	//ToString

	/**
	 * 
	 * Converte un'espressione in Stringa.
	 * Agevolandone la Stampa in seguito.
	 * 
	 */

	@Override
	public String toString() {
		return "Vento [dir_vel=" + dir_vel + ", data=" + data + ", ora=" + ora + ", minuti=" + minuti + "]";
	}

}



