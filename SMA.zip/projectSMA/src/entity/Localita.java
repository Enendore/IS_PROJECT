package entity;

/**
 * 
 * Dichiarazione della classe Localit�.
 * 
 * @author L. Arena, F. Caltabiano, V. D'Ambrosio, B. De Carlo.
 * 
 */

public class Localita {
	int idLoc;
	String NomeCitta;
	String CoordinateGPS;
	int CAP;

	//Costruttori
	
	/**
	 * 
	 * Costruttore di default della classe Localita'.
	 * 
	 */
	
	public Localita () {
		idLoc = 0;
		NomeCitta = "";
		CoordinateGPS = "";
		CAP = 0;

	}
	
	/**
	 * 
	 * Costruttore della classe Localita'.
	 * 
	 * @param loc										Identificativo della Localita'.
	 * @param Citta										Nome della Localit�.
	 * @param GPS										Coordinate della Localita'.
	 * @param CAP										CAP associato alla Localita'.
	 * 
	 */
	
	public Localita (int loc, String Citta, String GPS, int CAP) {
		idLoc = loc;
		NomeCitta = Citta;
		CoordinateGPS = GPS;
		this.CAP = CAP;

	}

	//Getters and Setters

	/**
	 * 
	 * Getter dell'identificativo della Localita'.
	 * 
	 * @return idLoc										Ritorno dell'identificativo della Localita' di interesse
	 * 
	 */
	
	public int getIdLoc() {
		return idLoc;
	}

	/**
	 * 
	 * Setter dell'identificativo della Localita'.
	 * 
	 * @param idLoc											Identificativo da inserire all'iterno dell'istanza Localita'.
	 * 
	 */
	
	public void setIdLoc(int idLoc) {
		this.idLoc = idLoc;
	}

	/**
	 * 
	 * Getter del nome della Localita'.
	 * 
	 * @return NomeCitt�									Ritorno del nome della Localita' di interesse.			
	 * 
	 */
	
	public String getNomeCitta() {
		return NomeCitta;
	}

	/**
	 * 
	 * Setter del nome della Localita'.
	 * 
	 * @param nomeCitta										Nome della citt� a inserire all'iterno dell'istanza di Localita'.
	 * 
	 */
	
	public void setNomeCitta(String nomeCitta) {
		NomeCitta = nomeCitta;
	}

	/**
	 * 
	 * Getter delle coorinate della Localita'.
	 * 
	 * @return CoordinateGPS								Ritorno delle coordinate GPS della Localita' di interesse.
	 * 
	 */
	
	public String getCoordinateGPS() {
		return CoordinateGPS;
	}

	/**
	 * 
	 * Setter delle coorinate della Localita'.
	 * 
	 * @param coordinateGPS										Coordinate GPS della Localita'.
	 * 
	 */
	
	public void setCoordinateGPS(String coordinateGPS) {
		CoordinateGPS = coordinateGPS;
	}

	/**
	 * 
	 * Getter del CAP della Localita'.
	 * 
	 * @return CAP												CAP della Localita' di interesse.
	 * 
	 */
	
	public int getCAP() {
		return CAP;
	}

	/**
	 * 
	 * Setter del CAP della Localita'.
	 * 
	 * @param cAP												CAP della Localita'.
	 * 
	 */
	
	public void setCAP(int cAP) {
		CAP = cAP;
	}
	
	/**
	 * 
	 * Stampa a video dei dati dell'istanza della Localita'.
	 * 
	 * @return 													Stringa contenente i valori della Localita'.
	 * 
	 */
	
	@Override
	public String toString() {
		return "Localit� [idLoc=" + idLoc + ", NomeCitt�=" + NomeCitta + ", CoordinateGPS=" + CoordinateGPS + ", CAP="
				+ CAP + "]";
	}

}
