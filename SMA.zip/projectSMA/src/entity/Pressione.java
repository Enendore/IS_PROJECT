package entity;

import java.util.Date;

/**
 * 
 * Dichiarazione della Classe Pressione.
 * 
 * @author L. Arena, F. Caltabiano, V. D'Ambrosio, B. De Carlo
 *
 */

public class Pressione extends Sensore {

	int bar ;
	Date data;
	int ora;
	int minuti;

	//Costruttori

	/**
	 * 
	 * Costruttore di Default della Classe.
	 * 
	 */

	public Pressione () {

		super ();
		bar = 0;
		data = new Date ();
		ora = 0;
		minuti = 0;

	}

	/**
	 * 
	 * Costruttore della Classe.
	 * 
	 * @param identificativo				ID del Sensore.
	 * @param marca							Marca del Sensore (Il Brand).
	 * @param tipo							Tipologia di Specializzazione del Sensore.
	 * @param idLocalita					ID della Localita' in cui il Sensore � collocato.
	 * @param status						Stato del sensore.
	 * @param bar							Valore del Dato contenuto nel sensore. (bar: Unit� di misura della pressione).
	 * @param data							Data attuale.
	 * @param ora							Ora attuale.
	 * @param minuti						Minuti attuali.
	 * 
	 */
	
	public Pressione (int identificativo,	String marca, int tipo,	int idLocalita,	boolean status, int bar, Date data, int ora, int minuti) {

		super (identificativo, marca, tipo, idLocalita, status);
		this.bar = bar;
		this.data = (Date) data.clone();
		this.ora = ora;
		this.minuti = minuti;

	}

	//Getters and Setters

	/**
	 * 
	 * Permette di ottenere il valore rilevato dal Sensore.
	 * 
	 * @return								Valore del Dato contenuto nel sensore. (bar: Unit� di misura della pressione).
	 * 
	 */
	
	public int getbar() {
		return bar;
	}

	/**
	 * 
	 * Salva all'intenro del Sensore il Valorte.
	 * 
	 * @param bar							Valore relativo alla pressione.
	 * 
	 */
	
	public void setbar(int bar) {
		this.bar = bar;
	}

	/**
	 * 
	 * Restituisce la Data a cui il Sensore fa Riferimento.
	 * 
	 * @return								Restituisce la Data a cui il Sensore fa Riferimento.
	 * 
	 */
	
	public Date getData() {
		return data;
	}

	/**
	 * 
	 * Permette di Settare il campo Data.
	 * 
	 * @param data							Data da inserire.
	 * 
	 */
	
	public void setData(Date data) {
		this.data = data;
	}

	/**
	 * 
	 * Restituisce l'Ora a cui il Sensore fa riferimento.
	 * 
	 * @return								Restituisce l'Ora a cui il Sensore fa riferimento.
	 * 
	 */
	
	public int getOra() {
		return ora;
	}

	/**
	 * 
	 * Permette di Settare il campo Ora.
	 * 
	 * @param ora							Ora da inserire.
	 * 
	 */
	
	public void setOra(int ora) {
		this.ora = ora;
	}

	/**
	 * 
	 * Restituisce i Minuti a cui il Sensore fa riferimento.
	 * 
	 * @return								Restituisce i Minuti a cui il Sensore fa riferimento.
	 * 
	 */
	
	public int getMinuti() {
		return minuti;
	}

	/**
	 * 
	 * Permette di Settare il campo Minuti.
	 * 
	 * @param minuti						Minuti da Inserire.
	 * 
	 */
	
	public void setMinuti(int minuti) {
		this.minuti = minuti;
	}


	//ToString

	/**
	 * 
	 * Converte un'espressione in Stringa.
	 * Agevolandone la Stampa in seguito.
	 * 
	 */
	
	@Override
	public String toString() {
		return "Pressione [bar=" + bar + ", data=" + data + ", ora=" + ora + ", minuti=" + minuti + "]";
	}

}
