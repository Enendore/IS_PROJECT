package entity;

/**
 * 
 * Dichiarazioe della classe OspiteRegistrato.
 * 
 * @author L. Arena, F. Caltabiano, V. D'Ambrosio, B. De Carlo.
 */

public class OspiteRegistrato implements Cloneable  {

	String username;
	String password;
	String email;
	
	/**
	 * 
	 * Costruttore di default della classe OspitRegistrato.
	 * 
	 */
	
	public OspiteRegistrato () {


		username = "";
		password = "";
		email = "";
	}
	
	/**
	 * 
	 * Costruttore della classe OspitRegistrato.
	 * 
	 * @param user										Nome da assegnare all'ospite.
	 * @param pass										Password da assegnare all'ospite.
	 * @param mail										E-mail da assegnare all'ospite.
	 * 
	 */
	
	public OspiteRegistrato ( String user, String pass, String mail) {


		username = user;
		password = pass;
		email = mail;
	}
	
	/**
	 * 
	 * Getter del parametro Username.
	 * 
	 * @return												Ritorno del valore del parametro username.
	 * 
	 */
	
	public String getUsername() {
		return username;
	}

	/**
	 * 
	 * Setter del parametro Username.
	 * 
	 * @param username										Valore username da inserire nell'istanza.
	 * 
	 */
	
	public void setUsername(String username) {
		this.username = username;
	}
	
	/**
	 * 
	 * Getter del parametro Password.
	 * 
	 * @return password										Ritorno del valore del parametro password.
	 * 
	 */
	
	public String getPassword() {
		return password;
	}
	
	/**
	 * 
	 * Setter del parametro Password.
	 * 
	 * @param password										Valore password da inserire nell'istanza. 
	 * 
	 */
	
	public void setPassword(String password) {
		this.password = password;
	}
	
	/**
	 * 
	 * Getter del parametro Email.
	 * 
	 * @return email										Ritorno del valore del parametro email.
	 * 
	 */
	
	public String getEmail() {
		return email;
	}
	
	/**
	 * 
	 * Setter del parametro Email.
	 * 
	 * @param email											Valore email da inserire nell'istanza. 
	 * 
	 */
	
	public void setEmail(String email) {
		this.email = email;
	}
	
	/**
	 * 
	 * Stampa a video i dati del'ospite.
	 * 
	 * @return												Ritorno della stringa contenente i valori dell'istanza OspiteRegistrato.
	 * 
	 */
	
	@Override
	public String toString() {
		return "OspiteRegistrato [username=" + username + ", password=" + password + ", email=" + email + "]";
	}
	
	/**
	 * 
	 * Funzione di copia dell'oggetto.
	 * 
	 * @return												Oggetto copiato.
	 * 
	 */
	
	@Override
	public Object clone() throws CloneNotSupportedException {
		return super.clone();	// TODO 
	}

}
