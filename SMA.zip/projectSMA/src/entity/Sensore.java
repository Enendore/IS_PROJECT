package entity;

/**
 * 
 * Dichiarazione della Classe Sensore.
 * 
 * @author L. Arena, F. Caltabiano, V. D'Ambrosio, B. De Carlo
 *
 */

public class Sensore {

	int identificativo;
	String marca;
	int tipo;
	int idLocalita;
	boolean status;

	//Costruttori

	/**
	 * 
	 * Costruttore di Default della Classe sensore.
	 * 
	 */
	
	public Sensore () {


		marca = "";
		tipo = 0;
		idLocalita = 0;
		status = true;

	}

	/**
	 * 
	 * Costruttore della Classe Sensore.
	 * 
	 * @param id						ID del Sensore.
	 * @param label						Modello del Sensore (il Brand).
	 * @param type						Tipologia di Specializzazione del Sensore.
	 * @param Localita					ID della Localit� a cui il Sensore fa riferimento.
	 * @param isOn						Stato del Sensore.
	 * 
	 */

	public Sensore (int id, String label, int type, int Localita, boolean isOn) {

		identificativo = id;
		marca = label;
		tipo = type;
		idLocalita= Localita;
		status = isOn;

	}

	//Getters and Setters

	/**
	 * 
	 * Permette di Ottenere l'Identificativo (ID) del Sensore.
	 * 
	 * @return							Ritorna l'ID del senore.
	 * 
	 */
	
	public int getIdentificativo() {
		return identificativo;
	}

	/**
	 * 
	 * Permette di Settare l'Identificativo (ID) del Settore.
	 * 
	 * @param identificativo			ID del Sensore.
	 * 
	 */
	
	public void setIdentificativo(int identificativo) {
		this.identificativo = identificativo;
	}

	/**
	 * 
	 * Permette di Ottenbere la Marca del Sensore.
	 * 
	 * @return							Ritorna la Marca del Sensore (Il Brand).
	 * 
	 */
	
	public String getMarca() {
		return marca;
	}

	/**
	 * 
	 * Permette di Settare la Marca del Sensore.
	 * 
	 * @param marca						Marca del Sensore.
	 * 
	 */
	
	public void setMarca(String marca) {
		this.marca = marca;
	}

	/**
	 * 
	 * Permette di Ottenere il Tipo del Sensore.
	 * 
	 * @return							Ritorna il Tipo del Sensore.
	 * 
	 */
	
	public int getTipo() {
		return tipo;
	}

	/**
	 * 
	 * Permette di Settare il Tipo del Sensore.
	 * 
	 * @param tipo						Tipologia di Specializzazione del Sensore.
	 * 
	 */

	public void setTipo(int tipo) {
		this.tipo = tipo;
	}

	/**
	 * 
	 * Permette di Ottenere l'ID della Localit�
	 * 
	 * @return							Ritorna l'ID della Localita'.
	 * 
	 */
	
	public int getIdLocalita() {
		return idLocalita;
	}

	/**
	 * 
	 * Permette di Settare l'ID della Localit�
	 * 
	 * @param idLocalita				ID della Localita'.
	 * 
	 */
	
	public void setIdLocalita(int idLocalita) {
		this.idLocalita = idLocalita;
	}

	/**
	 * 
	 * Permette di Ottenere lo Stato del Sensore.
	 * 
	 * @return							Ritorna lo Stato del Sensore.
	 * 
	 */
	
	public boolean isStatus() {
		return status;
	}

	/**
	 * 
	 * Permette di Settare lo Stato del Sensore.
	 * 
	 * @param status					Stato del Sensore.
	 */
	
	public void setStatus(boolean status) {
		this.status = status;
	}

	//ToString

	/**
	 * 
	 * Converte un'espressione in Stringa.
	 * Agevolandone la Stampa in seguito.
	 * 
	 */
	
	@Override
	public String toString() {
		return "Sensori [identificativo=" + identificativo + ", marca=" + marca + ", tipo=" + tipo + ", idLocalit�="
				+ idLocalita + ", status=" + status + "]";
	}

}