package boundary;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.Collection;
import java.util.Iterator;
import Controller.SMA_EIS;
import Controller.impl.GuestManagerImpl;
import entity.Localita;
import entity.OspiteRegistrato;
import entity.Pressione;
import entity.Sensore;
import entity.Temperatura;
import entity.Umidita;
import entity.Vento;

/**
 * 
 * Interfaccia Ospite.
 * 
 * @author L. Arena, F. Caltabiano, V. D'Ambrosio, B. De Carlo
 *
 */

public class BOspite{

	/**
	 * 
	 * ID della Localita'.
	 * 
	 */
	
	public int idLoc; 
	
	/**
	 * 
	 * Istanza di Ospite Registrato, inizialmente e' settata a null.
	 * 
	 */
	
	public OspiteRegistrato logged = null;

	/**
	 * 
	 * Costruttore dell'Interfaccia dell'Ospite.
	 * 
	 * @param consoleReader						Implementa la Possibilità di Leggere da Console.
	 * @param consoleWriter						Implementa la Possibilità di Scrivere su Console.
	 * @param logged							Ospite Registrato (loggato) che accede all'interfaccia.
	 * @throws IOException						Lancia Eccezioni riguardanti I/O.
	 * @throws SQLException						Lancia Eccezioni riguardanti la gestione della Base Dati.
	 * @throws CloneNotSupportedException		Lancia Eccezioni riguardanti la Clonazione.
	 * 
	 */

	public BOspite(BufferedReader consoleReader,  PrintWriter consoleWriter, OspiteRegistrato logged) throws IOException, SQLException, CloneNotSupportedException {
		this.consoleReader = consoleReader;
		this.consoleWriter = consoleWriter;
		this.logged = (OspiteRegistrato) logged.clone();

		if (logged.getEmail().equals(""))
			showBoundary();
	}

	/**
	 * 
	 * Ritorna un'istanza del Sistema.
	 * 
	 * @return 									Istanza del Controller.
	 *
	 */

	private SMA_EIS getSMA_EIS() {
		return SMA_EIS.getInstance();
	}


	/**
	 * 
	 * Funzione di Stampa.
	 * 
	 * @param s									Stringa da Stampare.
	 * @param params							Oggetto da Stampare.
	 * 
	 */

	private void print(String s, Object... params) {
		consoleWriter.format(s, params);
	}

	/**
	 * 
	 * Restituisce un'istanza del Boundary Ospite Registrato.
	 * 
	 * @param logged							Ospite Registrato (loggato) che accede all'interfaccia.
	 * @return BOspiteRegistrato				Istanza del Boundary Ospite	Registrato.
	 * @throws IOException						Lancia le Eccezioni riguardanti I/O.
	 * @throws SQLException						Lancia le Eccezioni riguardanti la gestione della Base Dati
	 * @throws CloneNotSupportedException		Lancia le Eccezioni riguardanti la Clonazione.
	 * 
	 */

	protected BOspiteRegistrato getBOspiteRegistrato(OspiteRegistrato logged) throws IOException, SQLException, CloneNotSupportedException {
		return new BOspiteRegistrato(consoleReader, consoleWriter, logged);
	}


	/**
	 * 
	 * Restituisce un'istanza del Boundary Admin.
	 * 
	 * @return BAdmin							Istanza del Boundary Admin.
	 * @throws IOException						Lancia le Eccezioni riguardanti I/O.
	 * @throws SQLException						Lancia le Eccezioni riguardanti la gestione della Base Dati
	 * @throws CloneNotSupportedException		Lancia le Eccezioni riguardanti la Clonazione.
	 * 
	 */

	protected BAdmin getBAdmin() throws IOException, SQLException, CloneNotSupportedException {
		return new BAdmin(consoleReader, consoleWriter, logged);
	}


	/**
	 * 
	 * Variabile di selezione che può assumere determinati valori per navigare nell'interfaccia.
	 *
	 */

	private static enum SelectionOptions {
		SEARCH_LOCATIONS,
		LOGIN,
		REGISTRATION,
		SHOWSENSORS,
		RENOTIFICATION,
		ADD_FAVOURITE,
		NEW_DATA,
		STATISTIC,
		HISTORY,
		BACK,
		EXIT
	}

	/**
	 *     
	 * Mostra l'interfaccia riguardante l'Ospite.    
	 *     
	 * @throws IOException						Lancia le Eccezioni riguardanti I/O.
	 * @throws SQLException						Lancia le Eccezioni riguardanti la gestione della Base Dati.
	 * @throws CloneNotSupportedException		Lancia le Eccezioni riguardanti la Clonazione.
	 * 
	 */

	public void showBoundary() throws IOException, SQLException, CloneNotSupportedException{
		SelectionOptions selectedOption = null;
		while (true) {
			selectedOption = chooseOption();

			if (selectedOption == SelectionOptions.SEARCH_LOCATIONS) {
				createNewSearch();
			} else if (selectedOption == SelectionOptions.LOGIN) {
				createLogin();
			} else if (selectedOption == SelectionOptions.REGISTRATION) {
				createUser();
			} else if (selectedOption == SelectionOptions.EXIT) {
				System.exit(0);
			}

				return;
		}

	}

	/**
	 * 
	 * Permette all'Ospite di scegliere quale funzionalita' eseguire.
	 * 
	 * @return									Corrisponde alla scelta effettuata, dirige la navigazione.
	 * @throws IOException						Lancia Eccezioni riguardanti I/O.
	 * 
	 */

	private SelectionOptions chooseOption() throws IOException {

		consoleWriter.format("BENVENUTO SULLA NOSTRA PIATTAFORMA DI MONITORAGGIO AMBIENTALE \n\n (Inserisci il numero della funzionalità alla quale vuoi accedere)\n\n");

		while (true) {
			print(" 0.  EFFETTUA IL LOGIN ;)\n");
			print(" 1. INSERISCI UN CAP PER RICERCARE I SENSORI DI UNA DETERMINATA LOCALITA' :)\n");
			print(" 2. REGISTRATI ALLA PIATTAFORMA PER ACCEDERE AD ALTRE FUNZIONALITA' ;)\n");
			print(" 3. ESCI DAL PROGRAMMA :( \n");

			try {
				int optionValue = Integer.parseInt(consoleReader.readLine());
				switch (optionValue) {
				case 0: return SelectionOptions.LOGIN;
				case 1: return SelectionOptions.SEARCH_LOCATIONS;
				case 2: return SelectionOptions.REGISTRATION;
				case 3: return SelectionOptions.EXIT;

				default: 
					print("AZIONE NON CONSENTITA! RIPROVA :|\n");
				}
			} catch (NumberFormatException e) {
				print("VALORE NON CONSENTITO:|\n");
			}
		}
	}

	/**
	 * 
	 * Mostra l'interfaccia riguardante la Localita'.
	 * 
	 * @throws IOException						Lancia le Eccezioni riguardanti I/O.
	 * @throws SQLException						Lancia le Eccezioni riguardanti la gestione della Base Dati.
	 * @throws CloneNotSupportedException		Lancia le Eccezioni riguardanti la Clonazione.
	 * 
	 */

	public void showBoundaryPlace() throws IOException, SQLException, CloneNotSupportedException {
		SelectionOptions selectedOption = null;
		while (true) { 
			selectedOption = chooseOptionPlace();

			if (selectedOption == SelectionOptions.ADD_FAVOURITE) {
				idLoc = Integer.parseInt(consoleReader.readLine());
				addFav(idLoc);
			} else if (selectedOption == SelectionOptions.RENOTIFICATION) {
				idLoc = Integer.parseInt(consoleReader.readLine());
				reNot(idLoc);
			} else if (selectedOption == SelectionOptions.SHOWSENSORS) {
				idLoc = Integer.parseInt(consoleReader.readLine());
				showSensors(idLoc);
			} else if (selectedOption == SelectionOptions.BACK) {
				if(logged == null)						// Se non è loggato, ritorna al Boundary Ospite.
					return;
				else
					getBOspiteRegistrato(logged);		// Se è loggato, ritorna Bounday OspiteRegistrato.
			} else

				return;
		}
	}

	/**
	 * 
	 * Permette all'Ospite di scegliere quale funzionalita' eseguire sulla Località.
	 * 
	 * @return									Corrisponde alla scelta effettuata, dirige la navigazione.
	 * @throws IOException						Lancia Eccezioni riguardanti I/O.
	 * 
	 */

	private SelectionOptions chooseOptionPlace() throws IOException {  
		consoleWriter.format("OPZIONI LOCALITA'\n\n");
		while (true) {
			print("0. VISUALIZZA I SENSORI DI UNA LOCALITA' -> \n");
			print("1. RICEVI NOTIFICHE RIGUARDO GLI AGGIORNAMENTI DI UNA LOCALITA' (i)\n");
			print("2. AGGIUNGI UNA LOCALITA AI PREFERITI (DEVI AVER EFFETTUATO LOGIN) (+) \n");
			print("3. LOG OUT \n");

			try {
				int optionValue = Integer.parseInt(consoleReader.readLine());
				consoleWriter.format("INSERISCI L'ID DELLA LOCALITA' A CUI VUOI APPLICARE LA FUNZIONALITA' (°)\n");
				switch (optionValue) {
				case 0: return SelectionOptions.SHOWSENSORS;
				case 1: return SelectionOptions.RENOTIFICATION;
				case 2: return SelectionOptions.ADD_FAVOURITE;
				case 3: return SelectionOptions.BACK;
				default: 
					print("AZIONE NON CONSENTITA! RIPROVA :|\n");
				}
			} catch (NumberFormatException e) {
				print("VALORE NON CONSENTITO:|\n");
			}
		}
	}

	/**
	 * 
	 * Mostra l'interfaccia riguardante i Sensori delle Localita'.
	 * 
	 * @throws IOException						Lancia le Eccezioni riguardanti I/O.
	 * @throws SQLException						Lancia le Eccezioni riguardanti la gestione della Base Dati.
	 * @throws CloneNotSupportedException		Lancia le Eccezioni riguardanti la Clonazione.
	 * 
	 */

	public void showBoundarySensor() throws IOException, SQLException, CloneNotSupportedException{
		SelectionOptions selectedOption = null;

		while (true) { 
			selectedOption = chooseOptionSensor();

			if (selectedOption == SelectionOptions.NEW_DATA) {
				int idSen = Integer.parseInt(consoleReader.readLine());


				getSensorData(idSen);
			} else if (selectedOption == SelectionOptions.STATISTIC) {
				int idSen = Integer.parseInt(consoleReader.readLine());


				getSensorStatistics(idSen);

			} else if (selectedOption == SelectionOptions.HISTORY) {
				int idSen = Integer.parseInt(consoleReader.readLine());


				getSensorHistory(idSen);
			} else if (selectedOption == SelectionOptions.BACK) {
				if(logged == null)						// Se non è loggato, mi tirotna al Boundary Ospite.
					return;
				else
					getBOspiteRegistrato(logged);		// Se è loggato, ritorna al Bounday OspiteRegistrato.

			} else

				return;
		}
	}

	/**
	 * 
	 * Permette all'Ospite di scegliere quale funzionalita' eseguire sul Sensore.
	 * 	
	 * @return									Corrisponde alla scelta effettuata, dirige la navigazione.
	 * @throws IOException						Lancia Eccezioni riguardanti I/O.
	 * 
	 */

	private SelectionOptions chooseOptionSensor() throws IOException {  
		consoleWriter.format("OPZIONI SENSORE\n\n");
		while (true) {
			print("0. VISUALIZZA I DATI PIU' RECENTI DEL SENSORE (§)\n");
			print("1. VISUALIZZA STATISTICHE DEL SENSORE (|/\\/\\|)\n");
			print("2. VISUALIZZA STORICO DEL SENSORE  (H)\n");
			print("3. LOG OUT \n");

			try {
				int optionValue = Integer.parseInt(consoleReader.readLine());
				consoleWriter.format("INSERISCI L'ID DEL SENSORE ALLA QUALE VUOI APPLICARE LA FUNZIONALITA' (°)\n");
				switch (optionValue) {
				case 0: return SelectionOptions.NEW_DATA;
				case 1: return SelectionOptions.STATISTIC;
				case 2: return SelectionOptions.HISTORY;
				case 3: return SelectionOptions.BACK;
				default: 
					print("AZIONE NON CONSENTITA! RIPROVA :|\n");
				}
			} catch (NumberFormatException e) {
				print("VALORE NON CONSENTITO :|\n");
			}
		}
	}  

	/**
	 * 
	 * Effettua la Ricerca delle Localita' associate ad un dato CAP.
	 * 
	 * @throws IOException						Lancia le Eccezioni riguardanti I/O.
	 * @throws SQLException						Lancia le Eccezioni riguardanti la gestione della Base Dati.
	 * @throws CloneNotSupportedException		Lancia le Eccezioni riguardanti la Clonazione.
	 * 
	 */

	protected void createNewSearch() throws IOException, SQLException, CloneNotSupportedException{

		consoleWriter.format("Inserisci Cap Localita da Ricercare: ");
		String parameter = consoleReader.readLine();

		int cap;	

		if (parameter.isEmpty()) {
			return;
		} else { 

			cap = Integer.parseInt(parameter); 	 
		}

		Collection<?> locList = getSMA_EIS().searchLocation(cap);

		if (locList != null && locList.size() != 0) {
			Iterator<?> it = locList.iterator();
			while (it.hasNext()) {
				Localita loc = (Localita) it.next();   
				print("LOCALITA' N."+loc.getIdLoc()+"\n");
				print("NOME CITTA: "+loc.getNomeCitta()+"\n");
				print("COORDINATE: "+loc.getCoordinateGPS()+"\n");
				print("CAP: "+String.valueOf(loc.getCAP())+"\n\n");
			}	

			showBoundaryPlace();			

		} else {
			print("NON SONO STATE TROVATE LOCALIA' CON IL CAP INSERITO\n");
		}

	}

	/**
	 * 
	 * Mostra i Sensori associati ad una Data Localita'.
	 * La Localita' è identificata univocamente da un proprio Identificativo (ID).
	 * 
	 * @param idLoc								ID della Localita'.
	 * @throws IOException						Lancia le Eccezioni riguardanti I/O.
	 * @throws SQLException						Lancia le Eccezioni riguardanti la gestione della Base Dati.
	 * @throws CloneNotSupportedException		Lancia le Eccezioni riguardanti la Clonazione.
	 * 
	 */

	private void showSensors(int idLoc) throws IOException, SQLException, CloneNotSupportedException{

		Collection<?> SensList = GuestManagerImpl.showSensors(idLoc);

		String nomSens = "";



		if (SensList != null && SensList.size() != 0) {
			Iterator<?> it = SensList.iterator();
			while (it.hasNext()) {
				Sensore sen = (Sensore) it.next();  

				if (sen.getTipo()==1) 
					nomSens = "Vento";
				else if (sen.getTipo()==2) 
					nomSens = "Pressione";
				else if (sen.getTipo()==3) 
					nomSens = "Temperatura";
				else if (sen.getTipo()==4) 
					nomSens = "Umidita'";


				print("MARCA:"+sen.getMarca()+"\n");
				print("TIPOLOGIA: " +nomSens+ "\n");
				print("STATUS: "+sen.isStatus()+"\n");
				print("IDSENSORE: "+sen.getIdentificativo()+"\n\n");
			}	

			showBoundarySensor();	


		} else {
			print("NON SONO STATE TROVATE LOCALITA' CON IL CAP INSERITO\n");
		}

	}

	/**
	 * 
	 * Fornisce i Dati memorizzati in un dato Sensore.
	 * Il Sensore è identificato univocamente da un proprio Identificativo (ID).
	 * In base al Tipo di Sensore verranno stampati Dati diversi.
	 * 
	 * @param idSensor							ID del Sensore.
	 * @throws IOException						Lancia le Eccezioni riguardanti I/O.
	 * @throws SQLException						Lancia le Eccezioni riguardanti la gestione della Base Dati.
	 * 
	 */

	private void getSensorData(int idSensor) throws IOException, SQLException{

		int tipo= getSMA_EIS().getSens(idSensor).getTipo();


		if(tipo==1) {
			print (" ~ ECCO I DATI DEL VENTO  ~ : \n");
			Vento ven = (Vento) getSMA_EIS().getData(idSensor,tipo);
			print("IDSENSORE: "+ven.getIdentificativo()+"\n");
			print("km/h e DIREZIONE:"+ven.getDir_vel()+"\n");
			print("DATA:"+ven.getData()+"\n");
			print("ORA ULTIMA RILEVAZIONE:"+ven.getOra()+":"+ven.getMinuti()+"\n\n");
		}
		else if(tipo==2){	

			print ("↑↓ ECCO I DATI DELLA PRESSIONE ↑↓  : \n");

			Pressione pre = (Pressione) dao.SensoreDAO.readData(idSensor,tipo);
			print("IDSENSORE: "+pre.getIdentificativo()+"\n");
			print("VALORE IN BAR: "+pre.getbar()+"\n");
			print("DATA:"+pre.getData()+"\n");
			print("ORA ULTIMA RILEVAZIONE:"+pre.getOra()+":"+pre.getMinuti()+"\n\n");
		}
		else if(tipo==3){

			print ("¶ ECCO I DATI DELLA TEMPERATURA ¶  : \n");

			Temperatura tem = (Temperatura) dao.SensoreDAO.readData(idSensor,tipo);
			print("IDSENSORE: "+tem.getIdentificativo()+"\n");
			print("GRADI CENTIGRADI: "+tem.getGradiCentigradi()+"\n");
			print("DATA:"+tem.getData()+"\n");
			print("ORA ULTIMA RILEVAZIONE:"+tem.getOra()+":"+tem.getMinuti()+"\n\n");
		}
		else if(tipo==4){

			print (" %⌂ ECCO I DATI DELL'UMIDITA' %⌂  : \n");

			Umidita umi = (Umidita) dao.SensoreDAO.readData(idSensor,tipo);
			print("IDSENSORE: "+umi.getIdentificativo()+"\n");
			print("PERCENTUALE: "+umi.getpercentuale()+"\n");
			print("DATA:"+umi.getData()+"\n");
			print("ORA ULTIMA RILEVAZIONE:"+umi.getOra()+":"+umi.getMinuti()+"\n\n");
		}
	}


	/**
	 * 
	 * Permette di Ottenere le Statistiche di un dato Sensore.
	 * Il Sensore e' identificato univocamente da un proprio Identificativo (ID).
	 * 
	 * @param idSensor							ID del Sensore. 
	 * @throws IOException						Lancia le Eccezioni riguardanti I/O.
	 * @throws SQLException						Lancia le Eccezioni riguardanti la gestione della Base Dati.
	 * 
	 */

	private void getSensorStatistics(int idSensor) throws IOException, SQLException{

		int tipo= getSMA_EIS().getSens(idSensor).getTipo();


		consoleWriter.format("Inserisci Data d'inizio, Formato yyyy-mm-dd  (al momento è disponibile solo 2020-12-10)");
		String startdate = consoleReader.readLine();

		consoleWriter.format("Inserisci Data di fine, Formato yyyy-mm-dd  (al momento è disponibile solo 2020-12-11)");
		String enddate = consoleReader.readLine();

		double[] valori = getSMA_EIS().getStats(idSensor, tipo, startdate, enddate);

		if(tipo==2 || tipo == 3){

			print("MINIMO: " +valori[1]+"\n");
			print("MEDIA: " +valori[0]+"\n");
			print("MASSIMO: " +valori[2]+"\n");

		}else print("PER IL SENSORE SELEZIONATO NON SONO PRESENTI STATISTICHE! \n\n");

	}


	/**
	 * 
	 * Permette di Ottenere lo Storico dei Dati di un dato Sensore.
	 * Il Sensore è identificato univocamente da un proprio Identificativo (ID). 
	 * 
	 * @param idSensor							ID del Sensore.
	 * @throws IOException						Lancia le Eccezioni riguardanti I/O.
	 * @throws SQLException						Lancia le Eccezioni riguardanti la gestione della Base Dati.
	 * 
	 */

	private void getSensorHistory(int idSensor) throws IOException, SQLException{

		int tipo= getSMA_EIS().getSens(idSensor).getTipo();


		consoleWriter.format("Inserisci Data d'inizio, Formato YYYY-MM-DD (al momento è disponibile solo 2020-12-10) \n");
		String startdate = consoleReader.readLine();

		consoleWriter.format("Inserisci Data di fine, Formato YYYY-MM-DD (al momento è disponibile solo 2020-12-11)\n");
		String enddate = consoleReader.readLine();

		Collection<Object> Collection = getSMA_EIS().getHistory(idSensor,tipo,startdate,enddate);

		if(tipo==2 || tipo == 3){

			if(tipo==2){


				if (Collection != null && Collection.size() != 0) {
					Iterator<?> it = Collection.iterator();
					while (it.hasNext()) {

						Pressione pre = (Pressione) it.next();
						print("IDSENSORE: "+pre.getIdentificativo()+"\n");
						print("VALORE: "+pre.getbar()+"\n");
						print("DATA RILEVAZIONE:"+pre.getData()+"\n");
						print("ORA RILEVAZIONE:"+pre.getOra()+":"+pre.getMinuti()+"\n\n");
					}
				}

			}
			else if(tipo==3){

				if (Collection != null && Collection.size() != 0) {
					Iterator<?> it = Collection.iterator();
					while (it.hasNext()) {

						Temperatura tem = (Temperatura) it.next();

						print("IDSENSORE: "+tem.getIdentificativo()+"\n");
						print("VALORE: "+tem.getGradiCentigradi()+"\n");
						print("DATA RILEVAZIONE:"+tem.getData()+"\n");
						print("ORA RILEVAZIONE:"+tem.getOra()+":"+tem.getMinuti()+"\n\n");

					}
				}

			}

		}else print("PER IL SENSORE SELEZIONATO NON E' PRESENTE LO STORICO \n\n");
	}

	/**
	 * 
	 * Permette ad un Ospite di effettuare il login.
	 * All'Ospite loggato viene fornita l'Interfaccia dell'Ospite Registrato.
	 * Il login riconosce l'Admin indirizzandolo alla propria Interfaccia.
	 * 
	 * @throws IOException						Lancia le Eccezioni riguardanti I/O.
	 * @throws SQLException						Lancia le Eccezioni riguardanti la gestione della Base Dati.
	 * @throws CloneNotSupportedException		Lancia le Eccezioni riguardanti la Clonazione.
	 * 
	 */

	private void createLogin() throws IOException, SQLException, CloneNotSupportedException{

		consoleWriter.format("Inserisci nome Utente: ");
		String user = consoleReader.readLine();
		consoleWriter.format("Inserisci Password: ");
		String password = consoleReader.readLine();

		if (user.isEmpty() || password.isEmpty()) {
			return;
		} else {
			logged = getSMA_EIS().login(user, password);
			if(!logged.getUsername().equals("")) {

				if(logged.getEmail().equals("amministratore@libero.it")) {

					getBAdmin();

				}else

					getBOspiteRegistrato(logged);

			}else 

				print("I DATI SONO ERRATI O NON SONO PRESENTI NEL DATABASE, RIPROVA (X)\n");
		}         
	}

	/**
	 * 
	 * Permette ad un Ospite di Registrarsi.
	 * Se i Dati forniti risultano già presenti, la richiesta viene abortita.
	 * 
	 * @throws IOException						Lancia le Eccezioni riguardanti I/O.
	 * @throws SQLException						Lancia le Eccezioni riguardanti la gestione della Base Dati.
	 * 
	 */

	private void createUser() throws IOException, SQLException{

		consoleWriter.format("Inserisci nome Utente: ");
		String user = consoleReader.readLine();
		consoleWriter.format("Inserisci Email: ");
		String email = consoleReader.readLine();
		consoleWriter.format("Inserisci Password: ");
		String password = consoleReader.readLine();


		if (user.isEmpty() || password.isEmpty() || email.isEmpty()) {
			return;
		} else {		
			if(getSMA_EIS().registration(user, email, password)) {

				print("SEI STATO REGISTRATO CORRETTAMENTE AL SITO (V)\n");

			}else 

				print("I DATI SONO GIA' PRESENTI NEL DATABASE, RIPROVA (X)\n");
		}

	}

	/**
	 * 
	 * Permette ad un Ospite Registrato di Aggiungere una Localita' ai propri Preferiti.
	 * 
	 * @param idLoc								ID della Localita'.
	 * @throws IOException						Lancia le Eccezioni riguardanti I/O.
	 * @throws SQLException						Lancia le Eccezioni riguardanti la gestione della Base Dati.
	 * 
	 */

	private void addFav(int idLoc) throws IOException, SQLException{


		if (!logged.equals(null)) {
			System.out.println(idLoc);
			if(getSMA_EIS().addFavourite(idLoc, logged.getEmail())) {
				print("LOCALITA' AGGIUNTA AI PREFERITI! \n");	   
			}else
				print("\nC'È STATO UN ERRORE NELL'AGGIUNTA AI PREFERITI! \n");	   
		}
	}


	/**
	 * 
	 * Abilità la Ricezione di Notifiche relative ai Dati di una Localita' di Interesse.
	 * 
	 * @param idLoc								ID della Localita'.
	 * @throws IOException						Lancia le Eccezioni riguardanti I/O.
	 * @throws SQLException						Lancia le Eccezioni riguardanti la gestione della Base Dati.
	 * 
	 */

	private void reNot(int idLoc) throws IOException, SQLException{

		consoleWriter.format("Inserisci il tuo numero di telefono: ");
		String tel = consoleReader.readLine();

		print("\n La tua richiesta al numero: " +tel + " sarà presa in carico dall'operatore!\n\n");

	}

	final BufferedReader consoleReader;
	final PrintWriter consoleWriter;
}
