package boundary;

import boundary.ApplicationBoundary.TerminationState;

/**
 * 
 * Main Sistema Monitoraggio Ambientale.
 * 
 * @author L. Arena, F. Caltabiano, V. D'Ambrosio, B. De Carlo
 *
 */

public class SMA_MAIN {

	/**
	 * 
	 * Funzione main del sistema.
	 *  
	 * @param args						argomenti di ingresso al main
	 */
	
    public static void main(String[] args) {
        ApplicationBoundary appBoundary = new ApplicationBoundary();
        TerminationState exitStatus = appBoundary.runApplication();
        
        if (exitStatus == TerminationState.CORRECT_TERMINATION) {
            System.exit(0);
        } else {
            System.exit(-1);
        }
    }

}
