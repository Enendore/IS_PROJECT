package boundary;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.Collection;
import java.util.Iterator;
import Controller.SMA_EIS;
import entity.Localita;
import entity.OspiteRegistrato;

/**
 * 
 * Interfaccia Ospite Registrato.
 * 
 * @author L. Arena, F. Caltabiano, V. D'Ambrosio, B. De Carlo
 *
 */

public class BOspiteRegistrato extends BOspite{

	final BufferedReader consoleReader;
	final PrintWriter consoleWriter;

	OspiteRegistrato logged;

	/**
	 * 
	 * Costruttore dell'Interfaccia dell'Ospite Registrato.
	 * 
	 * @param consoleReader						Implementa la Possibilit� di Leggere da Console.
	 * @param consoleWriter						Implementa la Possibilit� di Scrivere su Console.
	 * @param logged							Ospite Registrato (loggato) che accede all'interfaccia.
	 * @throws IOException						Lancia Eccezioni riguardanti I/O.
	 * @throws SQLException						Lancia Eccezioni riguardanti la gestione della Base Dati.
	 * @throws CloneNotSupportedException		Lancia Eccezioni riguardanti la Clonazione.
	 * 
	 */

	public BOspiteRegistrato(BufferedReader consoleReader, PrintWriter consoleWriter, OspiteRegistrato logged) throws IOException, SQLException, CloneNotSupportedException {
		super(consoleReader, consoleWriter, logged);
		this.consoleReader = consoleReader;
		this.consoleWriter = consoleWriter;
		this.logged = (OspiteRegistrato) logged.clone();
		
		if(!logged.getUsername().equals("Admin"))
			showBoundaryLogged();

	}

	/**
	 * 
	 * Ritorna un'istanza del Sistema.
	 * 
	 * @return 									Istanza del Controller.
	 * 
	 */

	private SMA_EIS getSMA_EIS() {
		return SMA_EIS.getInstance();
	}
	
	/**
	 * 
	 * Funzione di Stampa.
	 * 
	 * @param s									Stringa da Stampare.
	 * @param params							Oggetto da Stampare.
	 * 
	 */

	private void print(String s, Object... params) {
		consoleWriter.format(s, params);
	}
	
	/**
	 * 
	 * Restituisce un'istanza del Boundary Ospite.
	 * 
	 * @return 									Istanza del Boundary Ospite.									
	 * @throws IOException						Lancia Eccezioni riguardanti I/O.
	 * @throws SQLException						Lancia Eccezioni riguardanti la gestione della Base Dati.
	 * @throws CloneNotSupportedException		Lancia Eccezioni riguardanti la Clonazione.
	 * 
	 */

	private BOspite getBospite() throws IOException, SQLException, CloneNotSupportedException {
		BOspite bospite = new BOspite(consoleReader, consoleWriter, logged);
		return bospite;
	}

	/**
	 * 
	 * Variabile di selezione che pu� assumere determinati valori per navigare nell'interfaccia.
	 *
	 */

	private static enum SelectionOptions {
		SEARCH_LOCATIONS,
		SHOWSENSORS,
		RENOTIFICATION,
		ADD_FAVOURITE,
		STATISTIC,
		HISTORY,
		BACK,
		FAVOURITES,
		PERSONAL_DATA,
		LOGOUT,
		EXIT
	}

	/**
	 * 
	 * Mostra l'interfaccia riguardante l'Ospite Registrato (L'Ospite loggato).
	 * 
	 * @throws IOException						Lancia Eccezioni riguardanti I/O.
	 * @throws SQLException						Lancia Eccezioni riguardanti la gestione della Base Dati.
	 * @throws CloneNotSupportedException		Lancia Eccezioni riguardanti la Clonazione.
	 * 
	 */
	
	public void showBoundaryLogged() throws IOException, SQLException, CloneNotSupportedException {
		SelectionOptions selectedOption = null;
		while (true) {
			selectedOption = chooseOptionLogged();
	
			if (selectedOption == SelectionOptions.SEARCH_LOCATIONS) {
				getBospite().createNewSearch();
			} else if (selectedOption == SelectionOptions.FAVOURITES) {
				getFavourites(logged);
			} else if (selectedOption == SelectionOptions.PERSONAL_DATA) {
				getPersonalData(logged);
			} else 
				createLogout(logged);
	
			showBoundary();
			return;
		}
	
	}

	/**
	 * 
	 * Permette all'Ospite Registrato di scegliere quale funzionalit� eseguire.
	 * 
	 * @return									Corrisponde alla scelta effettuata, dirige la navigazione.
	 * @throws IOException						Lancia Eccezioni riguardanti I/O.
	 * 
	 */
	
	private SelectionOptions chooseOptionLogged() throws IOException {
	
		consoleWriter.format("BENTORNATO/A SULLA NOSTRA PIATTAFORMA, GENTILE "+logged.getUsername().toUpperCase() +" :) \n\n");
		while (true) {
			print("0. ESEGUI IL LOGOUT :(\n");
			print("1. INSERISCI UN CAP PER RICERCARE I SENSORI DI UNA DETERMINATA LOCALITA' :)\n");
			print("2. VISUALIZZA I TUOI LUOGHI PREFERITI;)\n");
			print("3. VISUALIZZA I TUOI DATI ;) \n\n");
	
			try {
				int optionValue = Integer.parseInt(consoleReader.readLine());
				switch (optionValue) {
				case 0: return SelectionOptions.LOGOUT;
				case 1: return SelectionOptions.SEARCH_LOCATIONS;
				case 2: return SelectionOptions.FAVOURITES;
				case 3: return SelectionOptions.PERSONAL_DATA;
	
				default: 
					print("AZIONE NON CONSENTITA! RIPROVA :|\n");
				}
			} catch (NumberFormatException e) {
				print("VALORE NON CONSENTITO:|\n");
			}
		}
	}

	/**
	 * 
	 * Permette il logout da parte dell'Ospite Registrato.
	 * 
	 * @param logged							Ospite Registrato (loggato) che si disconnette dall'interfaccia.
	 * @throws IOException						Lancia Eccezioni riguardanti I/O.
	 * @throws SQLException						Lancia Eccezioni riguardanti la gestione della Base Dati.
	 * 
	 */
	
	private void createLogout(OspiteRegistrato logged) throws IOException, SQLException{	//daprovare
		logged = null;
		print("LOGOUT ESEGUITO CON SUCCESSO! \n\n");	   
	}

	/**
	 * 
	 * Permette all'Ospite Registrato di vedere le Localit� da lui aggiunte ai Preferiti.
	 * 
	 * @param logged							Ospite Registrato (loggato) che si disconnette dall'interfaccia.
	 * @throws IOException						Lancia Eccezioni riguardanti I/O.
	 * @throws SQLException						Lancia Eccezioni riguardanti la gestione della Base Dati.
	 * @throws CloneNotSupportedException		Lancia Eccezioni riguardanti la Clonazione.
	 * 
	 */
	
	private void getFavourites(OspiteRegistrato logged) throws IOException, SQLException, CloneNotSupportedException{

		Collection<?> locList = getSMA_EIS().getFavourites(logged.getEmail());

		if (locList != null && locList.size() != 0) {
			Iterator<?> it = locList.iterator();
			while (it.hasNext()) {
				Localita loc = (Localita) it.next();   
				print("LOCALITA' N."+loc.getIdLoc()+"\n");
				print("NOME CITTA: "+loc.getNomeCitta()+"\n");
				print("COORDINATE: "+loc.getCoordinateGPS()+"\n");
				print("CAP: "+String.valueOf(loc.getCAP())+"\n\n");
			}	

			getBospite().showBoundaryPlace();			

		} else {
			print("NON SONO STATE TROVATE LOCALITA' TRA I PREFERITI\n");
		}	

	}

	/**
	 * 
	 * Permette all'OspiteRegistrato di visualizzare i Propri Dati.
	 * 
	 * @param logged							Ospite Registrato (loggato) che si disconnette dall'interfaccia.
	 * @throws IOException						Lancia Eccezioni riguardanti I/O.
	 * @throws SQLException						Lancia Eccezioni riguardanti la gestione della Base Dati.
	 * @throws CloneNotSupportedException		Lancia Eccezioni riguardanti la Clonazione.
	 * 
	 */
	
	private void getPersonalData(OspiteRegistrato logged) throws IOException, SQLException, CloneNotSupportedException{
		if (logged != null) {
			print("USERNAME:"+logged.getUsername()+"\n");
			print("EMAIL: "+logged.getEmail()+"\n");
			print("PASSWORD: "+logged.getPassword()+"\n");
			showBoundaryLogged();		

		} else 
			print("OCCORRE PRIMA EFFETTUARE IL LOGIN! \n");
	}

}
