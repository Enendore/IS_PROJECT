package boundary;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.Collection;
import java.util.Iterator;
import Controller.SMA_EIS;
import Controller.impl.AdminManagerImpl;
import entity.Localita;
import entity.OspiteRegistrato;
import entity.Sensore;

/**
 * 
 * Interfaccia Admin.
 * 
 * @author L. Arena, F. Caltabiano, V. D'Ambrosio, B. De Carlo
 *
 */

public class BAdmin extends BOspiteRegistrato{

	int SensorID;
	int LocID;
	OspiteRegistrato logged;

	/**
	 * 
	 * Costruttore dell'Interfaccia dell'Admin.
	 * 
	 * @param consoleReader						Implementa la Possibilit� di Leggere da Console.
	 * @param consoleWriter						Implementa la Possibilit� di Scrivere su Console.
	 * @param logged							Ospite Admin (loggato) che accede all'interfaccia.
	 * @throws IOException						Lancia Eccezioni riguardanti I/O.
	 * @throws SQLException						Lancia Eccezioni riguardanti la gestione della Base Dati.
	 * @throws CloneNotSupportedException		Lancia Eccezioni riguardanti la Clonazione.
	 * 
	 */

	public BAdmin(BufferedReader consoleReader, PrintWriter consoleWriter, OspiteRegistrato logged) throws IOException, SQLException, CloneNotSupportedException {
		super(consoleReader, consoleWriter, logged);
		showBoundaryAdmin();
	}

	/**
	 * 
	 * Variabile di selezione che pu� assumere determinati valori per navigare nell'interfaccia.
	 *
	 */

	private static enum SelectionOptions {
		EXIT,
		BACK,
		LOGOUT,
		MANAGE_SENSORS,
		ADD_SENSOR,
		UPDATE_SENSOR,
		DELETE_SENSOR,
	}

	/**
	 * 
	 * Ritorna un'istanza del Sistema.
	 * 
	 * @return SMA_EIS.getInstance()				Istanza del Controller.
	 * 
	 */

	private SMA_EIS getSMA_EIS() {
		return SMA_EIS.getInstance();
	}

	/**
	 * 
	 * Funzione di Stampa.
	 * 
	 * @param s									Stringa da Stampare.
	 * @param params							Oggetto da Stampare.
	 * 
	 */

	private void print(String s, Object... params) {
		consoleWriter.format(s, params);
	}

	/**
	 * 
	 * Mostra l'interfaccia riguardante l'Admin
	 * 
	 * @throws IOException							Lancia le Eccezioni riguardanti I/O.
	 * @throws SQLException							Lancia Eccezioni riguardanti la gestione della Base Dati.
	 * @throws CloneNotSupportedException		Lancia Eccezioni riguardanti la Clonazione.
	 * 
	 */

	public void showBoundaryAdmin() throws IOException, SQLException, CloneNotSupportedException {
		SelectionOptions selectedOption = null;
		while (true) {
			selectedOption = chooseOptionsAdmin();


			if (selectedOption == SelectionOptions.LOGOUT) {
				createLogout(logged);

			} else if (selectedOption == SelectionOptions.MANAGE_SENSORS) {

				manageSensor();
			} else 

				return;
		}

	}

	/**
	 * 
	 * Permette all'Admin di scegliere quale funzionalit� eseguire.
	 * 
	 * @return									Corrisponde alla scelta effettuata, dirige la navigazione.
	 * @throws IOException						Lancia Eccezioni riguardanti I/O.
	 * 
	 */

	private SelectionOptions chooseOptionsAdmin() throws IOException {     
		consoleWriter.format("BENVENUTO SULLA NOSTRA PIATTAFORMA DI GESTIONE SENSORI\n");
		while (true) {
			print("0. ESCI DAL PROGRAMMA :(\n");
			print("1. INSERISCI UNA LOCALITA' PER POTER GESTIRE I SENSORI :)\n");

			try {
				int optionValue = Integer.parseInt(consoleReader.readLine());
				switch (optionValue) {
				case 0: return SelectionOptions.LOGOUT;
				case 1: return SelectionOptions.MANAGE_SENSORS;
				default: 
					print("AZIONE NON CONSENTITA! RIPROVA :|\n");
				}
			} catch (NumberFormatException e) {
				print("VALORE NON CONSENTITO:|\n");
			}
		}
	}

	/**
	 * 
	 * Mostra l'Interfaccia riguardante i Sensori.
	 * 
	 * @throws IOException						Lancia Eccezioni riguardanti I/O.
	 * @throws SQLException						Lancia Eccezioni riguardanti la gestione della Base Dati.
	 * @throws CloneNotSupportedException		Lancia Eccezioni riguardanti la Clonazione.
	 * 
	 */

	public void showBoundarySensors() throws IOException, SQLException, CloneNotSupportedException {
		SelectionOptions selectedOption = null;
		while (true) {
			selectedOption = chooseOptionSensors();

			if (selectedOption == SelectionOptions.ADD_SENSOR) {

				addSensor();
			} else if (selectedOption == SelectionOptions.UPDATE_SENSOR) {
				updateSensor();
			} else if (selectedOption == SelectionOptions.DELETE_SENSOR) {
				deleteSensor();
			} else 
				showBoundaryAdmin();
			return;
		}

	}

	/**
	 * 
	 * Permette all'Admin di scegliere quale funzionalita' eseguire sul Sensore.
	 * 	
	 * @return									Corrisponde alla scelta effettuata, dirige la navigazione.
	 * @throws IOException						Lancia Eccezioni riguardanti I/O.
	 * 
	 */

	private SelectionOptions chooseOptionSensors() throws IOException {
		while (true) {
			print("0. TORNA INDIETRO <-\n");
			print("1. PER AGGIUNGERE UN SENSORE ALLA LOCALITA' SELEZIONATA :)\n");
			print("2. PER MODIFICARE UN SENSORE, OVVERO AGGIORNARE IL SUO STATO (ON/OFF)  ;)\n");
			print("3. PER ELIMINARE UN SENSORE DALLA LOCALITA' SELEZIONATA :(\n");

			try {
				int optionValue = Integer.parseInt(consoleReader.readLine());
				switch (optionValue) {
				case 0: return SelectionOptions.BACK;
				case 1: return SelectionOptions.ADD_SENSOR;
				case 2: return SelectionOptions.UPDATE_SENSOR;
				case 3: return SelectionOptions.DELETE_SENSOR;
				default: 
					print("AZIONE NON CONSENTITA! RIPROVA :|\n");
				}
			} catch (NumberFormatException e) {
				print("VALORE NON CONSENTITO:|\n");
			}
		}
	}


	/**
	 * 
	 * Permette il logout da parte dell'Admin.
	 * 
	 * @param logged							Ospite Admin (loggato) che si disconnette dall'interfaccia.
	 * @throws IOException						Lancia Eccezioni riguardanti I/O.
	 * @throws SQLException 					Lancia Eccezioni riguardanti la gestione della Base Dati.
	 * @throws CloneNotSupportedException		Lancia Eccezioni riguardanti la Clonazione.
	 * 
	 */

	private void createLogout(OspiteRegistrato logged) throws IOException, SQLException, CloneNotSupportedException{

		logged = null;
		print("LOGOUT ESEGUITO CON SUCCESSO!");	   
		showBoundary();


	}

	/**
	 * 
	 * Permette all'Admin di gestire i Sensori.
	 * 
	 * @throws IOException						Lancia Eccezioni riguardanti I/O.
	 * @throws SQLException						Lancia Eccezioni riguardanti la gestione della Base Dati.
	 * @throws CloneNotSupportedException		Lancia Eccezioni riguardanti la Clonazione.
	 * 
	 */

	private void manageSensor() throws IOException, SQLException, CloneNotSupportedException{

		consoleWriter.format("Inserisci Cap Localita da Ricercare: ");
		String parameter = consoleReader.readLine();
		int cap;	

		if (parameter.isEmpty()){
			return;
		} else{ 
			cap = Integer.parseInt(parameter); 	 
		}

		Collection<?> locList = getSMA_EIS().searchLocation(cap);

		if (locList != null && locList.size() != 0) {
			Iterator<?> it = locList.iterator();
			while (it.hasNext()) {
				Localita loc = (Localita) it.next();   
				print("LOCALITA' N."+loc.getIdLoc()+"\n");
				print("NOME CITTA: "+loc.getNomeCitta()+"\n");
				print("COORDINATE: "+loc.getCoordinateGPS()+"\n");
				print("CAP: "+String.valueOf(loc.getCAP())+"\n\n");
			}	

			consoleWriter.format("INSERISCI L'ID DELLA LOCALITA ALLA QUALE VUOI APPLICARE LA FUNZIONALITA' (�)\n");
			String par = consoleReader.readLine();

			if (par.isEmpty()) {
				return;
			} else { 

				idLoc = Integer.parseInt(par); 	
				consoleWriter.format("HAI SELEZIONATA LA LOCALITA CON ID:"+idLoc+"\n");
				LocID=idLoc;
				showBoundarySensors();	
			}

		} 
		else
			print("NON SONO STATE TROVATE LOCALIA' CON IL CAP INSERITO\n");
	}

	/**
	 * 
	 * Permetta all'Admin di Aggiungere un Sensore.
	 * I Sensori non possono essere pi� di 4.
	 * Pu� esserci un solo sensore per Tipo.
	 * 
	 * @throws IOException						Lancia Eccezioni riguardanti l'I/O.
	 * @throws SQLException						Lancia Eccezioni riguardanti la gestione della Base Dati.	
	 * @throws CloneNotSupportedException		Lancia Eccezioni riguardanti la Clonazione.					
	 * 
	 */

	private void addSensor() throws IOException, SQLException, CloneNotSupportedException{ 
		AdminManagerImpl A = new AdminManagerImpl();
		int s_tipo=0;
		if(A.numeroSensori(LocID) == 4) {
			print ("Gi� sono presenti 4 sensori, prego rimuoverne prima uno.\n");
			showBoundarySensors();
		} 
		else {
			Sensore s = new Sensore();
			consoleWriter.format("Inserisci il tipo del Sensore:\n");
			s_tipo=Integer.parseInt(consoleReader.readLine());

			while(s_tipo < 1 || s_tipo > 4) {
				print("il tipo inserito non � valido\n");
				consoleWriter.format("Inserisci il tipo del Sensore:\n");
				s_tipo=Integer.parseInt(consoleReader.readLine());
			}

			s.setIdentificativo(3);
			s=A.tipoPresente(LocID, s_tipo);

			if(s.getIdentificativo()!= 0) {
				print("il tipo del sensore � gi� presente\n");
				showBoundarySensors();
			} 
			else if(s.getIdentificativo()==0) {
				print("inserisci id sensore: \n");
				int idSens = Integer.parseInt(consoleReader.readLine());
				s.setIdentificativo(idSens);
				
				s.setIdLocalita(LocID);
				
				s.setTipo(s_tipo);
				
				consoleWriter.format("Inserisci la Marca del Sensore:\n");
				s.setMarca(consoleReader.readLine());
				
				consoleWriter.format("Inserisci lo stato del sensore:\n [0] se il sensore � spento\n [1] se il sensore � acceso\n");
				
				int var = Integer.parseInt( consoleReader.readLine());

                while(var!=0 && var!=1) {
                    print("Valore non consentito\n");
                    var = Integer.parseInt(consoleReader.readLine());
                }
                if (var == 0) {
                    s.setStatus(false);
                }
                else if(var == 1) {
                    s.setStatus(true);
                }
                
				A.addSensor(s);
			}
		}
	}

	/**
	 * 
	 * Permette all'Admin di Commutare lo stato di un Sensore (lo "Aggiorna").
	 * 
	 * @throws IOException						Lancia Eccezioni riguardanti l'I/O.
	 * @throws SQLException						Lancia Eccezioni riguardanti la gestione della Base Dati.
	 * @throws CloneNotSupportedException		Lancia Eccezioni riguardanti la Clonazione.
	 * 
	 */

	private void updateSensor() throws IOException, SQLException, CloneNotSupportedException{

		AdminManagerImpl A = new AdminManagerImpl();

		Collection<?> SensList = getSMA_EIS().showSensors(LocID);
		if (SensList != null && SensList.size() != 0) {
			Iterator<?> it = SensList.iterator();
			while (it.hasNext()) {
				Sensore sens = (Sensore) it.next();   
				print("IDENTIFICATIVO: "+sens.getIdentificativo()+"\n");
				print("MARCA: "+sens.getMarca()+"\n");
				print("TIPO: "+sens.getTipo()+"\n");
				print("ID LOCALITA': "+sens.getIdLocalita()+"\n");
				print("STATUS: "+String.valueOf(sens.isStatus())+"\n\n");
			}	
		}	

		Sensore s = new Sensore();

		print("Selezionare il tipo del sensore:\n");

		s.setTipo(Integer.parseInt (consoleReader.readLine()));

		while(s.getTipo() < 1 || s.getTipo() > 4) {
			print("il tipo inserito non � valido\n");
			consoleWriter.format("Inserisci il tipo del Sensore:\n");
			s.setTipo(Integer.parseInt(consoleReader.readLine()));
		}

		s=(A.tipoPresente(LocID, s.getTipo()));

		if(s.getIdentificativo()!=0) {
			print ("Lo stato del sensore �:"+ A.getStatus(s.getIdentificativo())+"\n Vuoi cambiarlo?\n(0: no, 1: si)");

			int optionValue = Integer.parseInt(consoleReader.readLine());
			while(optionValue!=0 && optionValue!=1) {
				print("Valore non consentito\n");
				optionValue = Integer.parseInt(consoleReader.readLine());}

			if(optionValue == 0) 
				showBoundarySensors();
			else if(optionValue == 1) 
				A.updateSensor(s);

		} else 
			print("Il sensore non � presente");

	}

	/**
	 * 
	 * Permette all'Admin di Eliminare un sensore.
	 * 
	 * @throws IOException						Lancia Eccezioni riguardanti l'I/O.
	 * @throws SQLException						Lancia Eccezioni riguardanti la gestione della Base Dati.
	 * @throws CloneNotSupportedException		Lancia Eccezioni riguardanti la Clonazione.
	 * 
	 */

	private void deleteSensor() throws IOException, SQLException, CloneNotSupportedException{
		AdminManagerImpl A = new AdminManagerImpl();
		Sensore sens= new Sensore();

		Collection<?> SensList = getSMA_EIS().showSensors(LocID);
		if (SensList != null && SensList.size() != 0) {
			Iterator<?> it = SensList.iterator();
			
			while (it.hasNext()) {
				sens = (Sensore) it.next();   
				print("IDENTIFICATIVO: "+sens.getIdentificativo()+"\n");
				print("MARCA: "+sens.getMarca()+"\n");
				print("TIPO: "+sens.getTipo()+"\n");
				print("ID LOCALITA': "+sens.getIdLocalita()+"\n");
				print("STATUS: "+String.valueOf(sens.isStatus())+"\n\n");
			}	
		}


		if(A.numeroSensori(LocID) == 0) {
			print ("Non esistono sensori per questa localit�");
			showBoundarySensors();

		}
		else{
			consoleWriter.format("Inserisci il tipo del Sensore:\n");
			int s_tipo = Integer.parseInt(consoleReader.readLine());
			sens = A.tipoPresente(LocID, s_tipo);
			if(sens.getIdentificativo()==0)
				print("Il sensore non � presente\n");
			else 	
				A.removeSensor(sens.getIdentificativo());
		}
	}
	
}







