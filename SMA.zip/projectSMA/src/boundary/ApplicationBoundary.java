package boundary;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.sql.SQLException;
import entity.OspiteRegistrato;

/**
 * 
 * Interfaccia Applicazione.
 * 
 * @author L. Arena, F. Caltabiano, V. D'Ambrosio, B. De Carlo
 *
 */

public class ApplicationBoundary {

	/**
	 * 
	 * Costruttore dell'Interfaccia dell'Applicazione.
	 * 
	 */
	
	public ApplicationBoundary() {
		final boolean AUTO_FLUSH_FLAG = true;

		this.consoleReader = new BufferedReader(new InputStreamReader(System.in));
		this.consoleWriter = new PrintWriter(System.out, AUTO_FLUSH_FLAG);
	}

/**
 * 
 * Restituisce un'istanza del Boundary Ospite.
 * 
 * @return BOspite 							Istanza del Boundary Ospite		
 * @throws IOException						Lancia le Eccezioni riguardanti I/O.
 * @throws SQLException						Lancia le Eccezioni riguardanti la gestione della Base Dati
 * @throws CloneNotSupportedException		Lancia le Eccezioni riguardanti la Clonazione.
 * 
 */
	
	protected BOspite getBOspite() throws IOException, SQLException, CloneNotSupportedException{

		OspiteRegistrato logged = new OspiteRegistrato();

		return new BOspite(consoleReader, consoleWriter, logged);

	}

/**
 * 
 * Funzione che permette di gestire l'errore.
 * 
 * @param e									Eccezione.
 * 
 */
	
	private void handleException(Exception e) {
		consoleWriter.format("Sorry! An exception occurred during the execution!\n");
		consoleWriter.format("The program must be terminated. Cause: %s\n",  e.getMessage());
		e.printStackTrace(consoleWriter);
	}

	/**
	 * 
	 * Restituisce lo Stato della Terminazione dell'Applicazione.
	 * 
	 * @return 								Stato della Terminazione
	 * 
	 */
	
	public TerminationState runApplication() {
		try {
			getBOspite();

			return TerminationState.CORRECT_TERMINATION;
		} catch (Exception e) {
			handleException(e);
			return TerminationState.ABNORMAL_TERMINATION;
		}
	}

	/**
	 * 
	 * Variabile Stato di Terminazione.
	 *
	 */
	
	public static enum TerminationState {
		
		/**
		 * 
		 * Terminazione Corretta.
		 * 
		 */
		
		CORRECT_TERMINATION,	
		
		/**
		 * 
		 * Terminazione Anomala.
		 * 
		 */
		
		ABNORMAL_TERMINATION	
	};

	private final BufferedReader consoleReader;
	private final PrintWriter consoleWriter;
}
