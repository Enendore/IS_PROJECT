package Controller;

import java.sql.SQLException;
import java.util.Collection;
import entity.*;

/**
 * 
 * Controllore GuestManager, contenente le firme delle funzioni utilizzate.
 * 
 * @author L. Arena, F. Caltabiano, V. D'Ambrosio, B. De Carlo
 *
 */

public interface  GuestManager {
	
	/**
	 * 
	 * Firma della Funzione di Registrazione Ospite.
	 * 
	 * @param user						Username richiesto all'Ospite per effettuare la Registrazione.
	 * @param pass						Password richiesta all'Ospite per effettuare la Registrazione.
	 * @param mail						Email richiesta all'Ospite per effettuare la Registrazione.
	 * @return							Restituisce un Boolean: Vero (Registrato) - Falso (Non Registrato).
	 * 
	 */

	public boolean registration (String user, String pass,String mail);

	/**
	 * 
	 * Firma della funzione per la Ricerca della Localita'.
	 * 
	 * @param cap						CAP da ricercare.
	 * @return							Restituisce tutte le localit� associate al CAP ricercato.
	 * @throws SQLException				Lancia Eccezioni riguardanti la gestione della Base Dati.
	 * 
	 */
	
	public Collection<Localita> searchLocation(int cap) throws SQLException;
	
	/**
	 * 
	 * Firma della Funzione per l'Ottenimento dei Dati dai Sensori.
	 * 
	 * @param idSen						ID del Sensore.
	 * @param tipo						Tipo del sensore (sua specializzazione).
	 * @return							Ritorna i Dati dei Sensori.
	 * @throws SQLException				Lancia Eccezioni riguardanti la gestione della Base Dati.
	 * 
	 */

	public Object getData(int idSen, int tipo) throws SQLException;
	
	/**
	 * 
	 * Firma della Funzione per l'Ottenimento del Sensore.
	 * 
	 * @param identificativo			ID del Sensore.
	 * @return							Restituisce il Sensore.
	 * @throws SQLException				Lancia Eccezioni riguardanti la gestione della Base Dati.
	 * 
	 */
	
	public Sensore readSensor (int identificativo)throws SQLException;
	
	/**
	 * 
	 * Firma della Funzione di Ottenimento delle Statistiche sul Sensore.
	 * 
	 * @param idSen						ID del Sensore.
	 * @param type						Tipo del sensore (sua specializzazione).
	 * @param start						Data da cui iniziare l'Analisi.
	 * @param end						Data in cui terminare l'Analisi.
	 * @return							Ritorna le Statistiche innerenti al Sensore scelto.
	 * @throws SQLException				Lancia Eccezioni riguardanti la gestione della Base Dati.
	 * 
	 */

	double[] getStats(int idSen, int type, String start, String end) throws SQLException;

	/**
	 * 
	 * Firma della Funzione di Ottenimento dello Storico del Sensore.
	 * 
	 * @param idLoc								Identificativo della localita' di interesse.
	 * @param tipo								Specializzazione (il Tipo) del Sensore.
	 * @param datain							Data da cui iniziare ad elaborare lo Storico.
	 * @param fine								Data in cui termina lo Storico.
	 * @return 									Ritorno del vettore dello storico dei dati.
	 * @throws SQLException						Lancia Eccezioni riguardanti la gestione della Base Dati.
	 * 
	 */

	public  Collection<Object> getHistory(int idLoc,int tipo, String datain, String fine) throws SQLException; 
	
	/**
	 * 
	 * Firma della Funzione di Aggiunta delle Localita' ai Preferiti.
	 * 
	 * @param idLoc						ID del Sensore.
	 * @param email						Email associata all'Utente Registrato. 
	 * @return							Restituisce un Boolean: Vero (Aggiunto) - Falso (Non Aggiunto).
	 * @throws SQLException				Lancia Eccezioni riguardanti la gestione della Base Dati.
	 * 
	 */

	public boolean addFavourite(int idLoc, String email) throws SQLException;
	
	/**
	 * 
	 * Firma della Funzione per la visione dei Preferiti Aggiunti.
	 * 
	 * @param email						Email associata all'Utente Registrato.
	 * @return							Ritorna le Localita' aggiunte ai Preferiti.
	 * @throws SQLException				Lancia Eccezioni riguardanti la gestione della Base Dati.
	 * 
	 */

	public Collection <Localita> getFavourites (String email) throws SQLException;
	
	/**
	 * 
	 * Firma della Funzione per la Rimozione dei Preferiti.
	 * 
	 * @param idLoc						ID della Localita' che si intende rimuovere dai preferiti.
	 * @throws SQLException				Lancia Eccezioni riguardanti la gestione della Base Dati.
	 * 
	 */
	
	public void destroyFavourite (int idLoc) throws SQLException;

	/**
	 * 
	 * Firma della Funzione che mostra all'Utente Registrato i propri Dati.
	 * 
	 * @param email						Email associata all'Utente registrato.
	 * @return							Ritorna l'Utente Registrato, tramite cui � poossibile accedere ai vari dati personali.
	 * @throws SQLException				Lancia Eccezioni riguardanti la gestione della Base Dati.
	 * 
	 */

	public OspiteRegistrato showPersonalData (String email)throws SQLException;

}
