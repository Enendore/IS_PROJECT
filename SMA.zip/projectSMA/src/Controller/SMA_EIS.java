package Controller;

import java.sql.SQLException;
import java.util.Collection;
import Controller.impl.DefaultSMA_EISBuilder;
import entity.Localita;
import entity.OspiteRegistrato;
import entity.Sensore;

/**
 * 
 * Controllore di Sistema.
 * 
 * @author L. Arena, F. Caltabiano, V. D'Ambrosio, B. De Carlo.
 * 
 */

final public class SMA_EIS {

	private static SMA_EIS instance;

	final private AuthenticationManager authenticationManager;
	final private AdminManager adminManager;
	final private GuestManager guestManager;

	/**
	 * 
	 * Getter della variabile instance.
	 * 
	 * @return 										Ritorna un istanza di SMA_EIS.
	 * 
	 */
	
	public synchronized static SMA_EIS getInstance() {
		if (instance == null) {
			instance = new DefaultSMA_EISBuilder().build();
		}
		return instance;
	}

	/**
	 * 
	 * Classe costruttore del controllore.
	 * 
	 * @author L. Arena, F. Caltabiano, V. D'Ambrosio, B. De Carlo.
	 * 
	 */
	
	public abstract static class SMA_EISBuilder {
		
		/**
		 * 
		 * Costruttore di SMAEIS_Builder.
		 * 
		 * @param authenticationManager				Istanza di authenticationmanager che accede al sistema.
		 * @param adminManager						Istanza di adminManager che accede al sistema.
		 * @param guestManager						Istanza di guestManager che accede al sistema.
		 * @return new SMA_EIS						Ritorna una nuova istanza di SMA_EIS.
		 * 
		 */
		
		protected SMA_EIS build(AuthenticationManager authenticationManager, AdminManager adminManager, GuestManager guestManager) {
			return new SMA_EIS(authenticationManager, adminManager, guestManager);
		}  
		
		/**
		 *       
		 * Costruttore di default di SMA_EIS.     
		 *       
		 * @return 									Ritorna una nuova istanza di SMA_EIS.
		 * 
		 */
		
		public abstract SMA_EIS build();

	}
	
	/**
	 * 
	 * Setter dei valori di SMA_EIS.
	 * 
	 * @param authenticationManager				Variabile da assegnare al campo di AuthenticationManager.
	 * @param adminManager						Variabile da assegnare al campo di AdminManager.
	 * @param guestManager						Variabile da assegnare al campo di GuestManager.
	 * 
	 */
	
	protected SMA_EIS(AuthenticationManager authenticationManager, AdminManager adminManager, GuestManager guestManager) {
		this.authenticationManager = authenticationManager;
		this.adminManager = adminManager;
		this.guestManager = guestManager;
	}
	
	/**
	 * 
	 * Funzione che riporta i dati del sensore cercato.
	 * 
	 * @param identificativo					Identificativo del sensore di interesse.
	 * @return									ritorna i dati del sensore.
	 * @throws SQLException						Lancia Eccezioni riguardanti la gestione della Base Dati.
	 * 
	 */
	
	public Sensore getSens( int  identificativo) throws SQLException{

		return guestManager.readSensor(identificativo);
	}

	/**
	 * 
	 * Funzione per l'aggiunta di un sensore.
	 * 
	 * @param sensore							Sensore da aggiungere.
	 * @throws SQLException						Lancia Eccezioni riguardanti la gestione della Base Dati.
	 * 
	 */
	
	public void addSensor(Sensore sensore) throws SQLException {
		adminManager.addSensor(sensore);
		return;
	}
	
	/**
	 * 
	 * Funzione per Commutare lo Satto del Sensore (lo "Aggiorna").
	 * 
	 * @param sensore							Sensore da aggiungere.
	 * @throws SQLException						Lancia Eccezioni riguardanti la gestione della Base Dati.
	 * 
	 */
	
	public void updateSensor(Sensore sensore) throws SQLException{
		adminManager.updateSensor(sensore);
	}

	/**
	 * 
	 * Funzione che rimuove un sensore.
	 * 
	 * @param idsens							Identificativo del sensore da rimuovere.
	 * @throws SQLException						Lancia Eccezioni riguardanti la gestione della Base Dati.
	 * 
	 */
	
	public void removeSensor(int idsens) throws SQLException {
		adminManager.removeSensor(idsens);
		return;
	}

	/**
	 * 
	 * Calcola il numero di sensori in una specifica localita'.
	 * 
	 * @param idLoc							Identificativo della localita' di interesse.
	 * @return								Ritorna il numero di sensori nella localita' indicata.			
	 * @throws SQLException					Lancia Eccezioni riguardanti la gestione della Base Dati.
	 * 
	 */
	
	public int numeroSensori(int idLoc) throws SQLException {
		return adminManager.numeroSensori(idLoc);
	}

	/**
	 * 
	 * Funzione che indica se un dato tipo id sensore � presente nella localita' di interesse.
	 * 
	 * @param idLoc								Identificativo della localit� di interesse.
	 * @param tipoSens							Tipo di sensore da cercare.
	 * @return tipoPresente()					Ritorna il sensore se � stato trovato o ritorna un sensore vuoto.
	 * @throws SQLException						Lancia Eccezioni riguardanti la gestione della Base Dati.
	 * 
	 */
	
	public Sensore tipoPresente(int idLoc, int tipoSens) throws SQLException {
		return adminManager.tipoPresente(idLoc, tipoSens);
	}

	/**
	 * 
	 * Funzione che riporta lo stato del sensore di interesse.
	 * 
	 * @param identificativo					Identificativo del sensore da cercare.
	 * @return									Ritorno dello stato del sensore cercato.
	 * @throws SQLException						Lancia Eccezioni riguardanti la gestione della Base Dati.
	 * 
	 */
	
	public boolean getStatus(int identificativo) throws SQLException {
		return adminManager.getStatus(identificativo);
	}

	/**
	 * 
	 * Funzione che permette la registraione di un utente al sistema.
	 * 
	 * @param user								Nome del nuovo ospite.
	 * @param pass								Password del nuovo ospite.
	 * @param mail								E-mail del nuovo ospite.
	 * @return									Ritorna la registrazione Effettuata.
	 * 
	 */
	
	public boolean registration (String user, String pass,String mail){
		return guestManager.registration(user, mail, pass);

	}

	/**
	 * 
	 * Ricerca della localita' tramite CAP.
	 * 
	 * @param cap								CAP della localita' da cercare.
	 * @return 									Ritorno del vettore di localita' aventi il dato CAP.
	 * @throws SQLException						Lancia Eccezioni riguardanti la gestione della Base Dati.
	 * 
	 */
	
	public Collection<Localita> searchLocation(int cap) throws SQLException {
		return guestManager.searchLocation(cap);
	}

	/**
	 * 
	 * Funzione da le statistiche di un dato sensore.
	 * 
	 * @param idSens							Identificativo del sensore di interesse.
	 * @param type								Tipo del sensore di interesse.
	 * @param start								Data di inizio dell'analisi.
	 * @param end								Data fine analisi.
	 * @return 									Ritorna le Statistiche inerenti al Sensore scelto.
	 * @throws SQLException						Lancia Eccezioni riguardanti la gestione della Base Dati.
	 * 
	 */
	
	public double[] getStats(int idSens, int type, String start,String end ) throws SQLException{
		return guestManager.getStats(idSens,type, start, end);
	}

	/**
	 * 
	 * Funzione che legge lo storico dei dati di un specifica localita' in una determinata data.
	 * 
	 * @param idLoc								Identificativo della localita' di interesse.
	 * @param tipo								Specializzazione (il Tipo) del Sensore.
	 * @param datain							Data da cui iniziare ad elaborare lo Storico.
	 * @param fine								Data in cui termina lo Storico.
	 * @return 									Ritorno del vettore dello storico dei dati.
	 * @throws SQLException						Lancia Eccezioni riguardanti la gestione della Base Dati.
	 * 
	 */
	
	public Collection<Object> getHistory(int idLoc,int tipo, String datain, String fine) throws SQLException{
        return guestManager.getHistory(idLoc,tipo,datain,fine);
    }

	/**
	 * 
	 * Funzione che Aggiunge una localita' ai preferiti di un ospite registrato.
	 * 
	 * @param idLoc								Identificativo della localit� di interesse.
	 * @param email								E-amil dell'ospite di interesse.
	 * @return 									Ritorno dell'aggiunta ai preferiti.	
	 * @throws SQLException						Lancia Eccezioni riguardanti la gestione della Base Dati.
	 * 
	 */
	
	public boolean addFavourite (int idLoc, String email) throws SQLException{
		return guestManager.addFavourite(idLoc, email); 
	}

	/**
	 * 
	 * Funzione che mostra la lista dei preferiti di uno specifico utente.
	 * 
	 * @param email								E-mail dell'utente.
	 * @return									Vettore dellelocalit�.
	 * @throws SQLException						Lancia Eccezioni riguardanti la gestione della Base Dati.
	 * 
	 */
	
	public Collection <Localita> getFavourites (String email) throws SQLException{
		return guestManager.getFavourites(email);

	}

	/**
	 * 
	 * Funzione che recupera le rilevazioni di un sensore.
	 * 
	 * @param idSen								Identificativo del sensore.
	 * @param tipo								Tipo del sensore.
	 * @return 									Ritorna le rilevazioni del sensore.
	 * @throws SQLException						Lancia Eccezioni riguardanti la gestione della Base Dati.
	 * 
	 */
	
	public Object getData(int idSen,int tipo) throws SQLException {
		return guestManager.getData(idSen, tipo);
	}

	/**
	 * 
	 * Mostra le informazioi personali dell'ospite.
	 * 
	 * @param email								E-mail dell'ospite di interesse.
	 * @return 									Ritorna un istanza di Ospiteregistrato avente i dati dell'ospite.			
	 * @throws SQLException						Lancia Eccezioni riguardanti la gestione della Base Dati.
	 */
	
	public OspiteRegistrato showPersonalData (String email)throws SQLException{
		return guestManager.showPersonalData(email);

	}

	/**
	 * 
	 * Rimuove una localita' dai preferiti di un ospite.
	 * 
	 * @param idLoc								Identificativo della localita' da rimuovere.
	 * @throws SQLException						Lancia Eccezioni riguardanti la gestione della Base Dati.
	 * 
	 */
	
	public void destroyFavourite (int idLoc) throws SQLException{
		// TODO
	}

	/**
	 * 
	 * Funzione che effettua l'accesso al sistema come ospiti registrati.
	 * 
	 * @param username							Nome dell'utente.
	 * @param password							Password collegata al nome dell'utente.
	 * @return 									Ritorna un istanza di OspiteRegistrato.
	 * 
	 */

	public OspiteRegistrato login(String username, String password){
		return authenticationManager.login(username, password);
	}

	/**
	 * 
	 * Funzione che effettua l'uscita dal sistema come ospiti registrati.
	 * 
	 * @param email								E-mail dell'ospite.
	 * 
	 */
	
	public void logout(String email) {
		authenticationManager.logout(email);
		return;
	}

	/**
	 * 
	 * Funzione che controlla i dati di un utente.
	 * 
	 * @param cellulare							Numero di telefono dell'ospite.
	 * @param user								Nome dell'ospite.
	 * @param pass								Password dell'ospite.
	 * @param mail								E.amil dell'ospite.
	 * @return 									Variabile che indica se i dati sono inseriti correttamente.
	 * @throws SQLException						Lancia Eccezioni riguardanti la gestione della Base Dati.
	 * 
	 */
	
	public boolean checkData(long cellulare, String user, String pass, String mail) throws SQLException {	
		return false;	// TODO
	}

	/**
	 * 
	 * Funzione che controlla se il CAP � inserito correttamente.
	 * 
	 * @param CAP								CAP su cui effettuare il controllo.
	 * @return									Variabile che indica se il CAP e' stato inserito correttamente.
	 * @throws SQLException						Lancia Eccezioni riguardanti la gestione della Base Dati.
	 * 
	 */
	
	public boolean checkCAP(int CAP) throws SQLException {
		return false;	// TODO
	} 
	
	/**
	 * 
	 * Funzione che controlla se il numero inserito e' valido.
	 * 
	 * @param cell								Numero di cellulare da controllare.
	 * @return									Variabile che indica se il numero di telefono e' stato inserito correttamente.
	 * @throws SQLException						Lancia Eccezioni riguardanti la gestione della Base Dati.
	 * 
	 */
	
	public boolean checkCell (int cell) throws SQLException {
		return false;	// TODO
	}
	
	/**
	 * 
	 * Funzione che mostra i Dati appartenenti ai Sensori di in una localit�.
	 * 
	 * @param idLoc								Identificativo della localita' sulla quale effetuare la ricerca.
	 * @return									Ritorno di un vettore di sensori appartenenti alla data localit�.
	 * @throws SQLException						Lancia Eccezioni riguardanti la gestione della Base Dati.
	 * 
	 */
	public Collection<Sensore> showData(int idLoc) throws SQLException {
		return null;	// TODO
	} 


	/**
	 * 
	 * Aggiorna i vlaori delle rilevazioni dei sensori di temperatua e pressione.
	 * 
	 * @param identificativo					Identificativo della localita'.
	 * @throws SQLException						Lancia Eccezioni riguardanti la gestione della Base Dati.
	 * 
	 */
	public void updateValuesTP (int identificativo)throws SQLException {
		// TODO
	}


	/**
	 * 
	 * Aggiorna i valori delle rilevazioni dei sensori di vento e umidita'.
	 * 
	 * @param identificativo					Identificativo della localita'.
	 * @throws SQLException						Lancia Eccezioni riguardanti la gestione della Base Dati.
	 * 
	 */
	public void updateValuesVU (int identificativo)throws SQLException {
		// TODO
	}


	/**
	 * Funzione che si attiva ogni 15 minuti.
	 * 
	 * @return									Variabile che diventa vera ogni 15 minuti.
	 * 
	 */
	
	public boolean checkTime15() {
		return false;	// TODO
	}


	/**
	 * Funzione che si attiva ogni 60 minuti.
	 * 
	 * @return									Variabile che diventa vera ogni 60 minuti.
	 * 
	 */
	
	public boolean checkTime60() {
		return false;	// TODO
	}


	/**
	 * 
	 * Funzione che mostra i sensori in una localita'.
	 * 
	 * @param idLoc								Identificativo della localita' sulla quale effetuare la ricerca.
	 * @return									Ritorno di un vettore di sensori appartenenti alla data localita'.
	 * @throws SQLException						Lancia Eccezioni riguardanti la gestione della Base Dati.
	 * 
	 */
	
	public Collection <Object> showSensors (int idLoc) throws SQLException{
		return adminManager.showSensors(idLoc);

	}
	
}
