package Controller.impl;

import java.sql.SQLException;
import java.util.Collection;
import Controller.GuestManager;
import dao.LocalitaDAO;
import entity.Localita;
import entity.OspiteRegistrato;
import entity.Pressione;
import entity.Sensore;
import entity.Temperatura;
import entity.Umidita;
import entity.Vento;
import java.util.Iterator;

/**
 * 
 * Controllore dell'Utilizzo del Sistema ad opera degli Utenti, mediante implementazione delle funzioni DAO.
 * 
 * @author L. Arena, F. Caltabiano, V. D'Ambrosio, B. De Carlo
 *
 */

public class GuestManagerImpl implements GuestManager {

	/**
	 * 
	 * Funzione di Registrazione nel Sistema, mediante funzione DAO.
	 * 
	 * @param user						Username richiesto all'Ospite per effettuare la Registrazione.
	 * @param pass						Password richiesta all'Ospite per effettuare la Registrazione.
	 * @param mail						Email richiesta all'Ospite per effettuare la Registrazione.
	 * @return							Restituisce un Boolean: Vero (Registrato) - Falso (Non Registrato).
	 * 
	 */

	@Override
	public boolean registration(String user, String pass,String mail) {
		OspiteRegistrato os = new OspiteRegistrato(user, pass, mail);
		try {
			return dao.OspiteRegistratoDAO.create(os);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}

	/**
	 * 
	 * Funzione che ricerca le Localita' associate ad un CAP, mediante funzione DAO.
	 * 
	 * @param cap						CAP da ricercare.
	 * @return							Restituisce tutte le localita' associate al CAP ricercato.
	 * @throws SQLException				Lancia Eccezioni riguardanti la gestione della Base Dati.
	 * 
	 */

	@Override
	public Collection<Localita> searchLocation(int cap) throws SQLException {
		return LocalitaDAO.readListaLocalita(cap);
	}

	/**
	 * 
	 * Funzione per ottenere i Dati di uno specifico sensore, mediante funzione DAO.
	 * 
	 * @param idSen						ID del Sensore.
	 * @param tipo						Tipo del sensore (sua specializzazione).
	 * @return							Ritorna i Dati dei Sensori.
	 * @throws SQLException				Lancia Eccezioni riguardanti la gestione della Base Dati.
	 * 
	 */

	@Override
	public Object getData(int idSen,int tipo) throws SQLException {
		if(tipo==1){
			Vento ven = (Vento) dao.SensoreDAO.readData(idSen, tipo);
			return ven;
		}
		else if(tipo==2){
			Pressione pre = (Pressione) dao.SensoreDAO.readData(idSen, tipo);
			return pre;
		}
		else if(tipo==3){
			Temperatura tem = (Temperatura) dao.SensoreDAO.readData(idSen, tipo);
			return tem;
		}
		else if(tipo==4){
			Umidita umi = (Umidita) dao.SensoreDAO.readData(idSen, tipo);
			return umi;
		}
		return null;
	}

	/**
	 * 
	 * Funzione per l'Ottenimento delle Informazioni del Sensore, mediante Funzione DAO.
	 * 
	 * @param identificativo			ID del Sensore.
	 * @return							Restituisce il Sensore.
	 * @throws SQLException				Lancia Eccezioni riguardanti la gestione della Base Dati.
	 * 
	 */

	@Override
	public Sensore readSensor ( int identificativo)throws SQLException {
		return dao.SensoreDAO.readSensore(identificativo);
	}

	/**
	 * 
	 * Funzione per l'Ottenimento dei Sensori associati ad una Data Localit�, mediante Funzione DAO.
	 * 
	 * @param idLoc						ID della Localita'.
	 * @return							Ritorna il Vettore di Sensori associato alla Localit�.
	 * @throws SQLException				Lancia Eccezioni riguardanti la gestione della Base Dati.
	 * 
	 */


	public static Collection<Object> showSensors(int idLoc) throws SQLException {
		return dao.SensoreDAO.readListaSensori(idLoc);
	}

	/**
	 * 
	 * Funzione di Ottenimento delle Statistiche, mediante funzione DAO.
	 * 
	 * @param idSen						ID del Sensore.
	 * @param type						Tipo del sensore (sua specializzazione).
	 * @param start						Data da cui iniziare l'Analisi.
	 * @param end						Data in cui terminare l'Analisi.
	 * @throws SQLException				Lancia Eccezioni riguardanti la gestione della Base Dati.
	 * 
	 */

	@Override
	public double[] getStats(int idSen,int type, String start, String end) throws SQLException {

		double[] valori = new double[5];

		Collection<Object> Collection = dao.SensoreDAO.readSensorData(idSen, type, start, end);

		double tocalc[] = new double[Collection.size()];

		double media = 0;
		double massimo =0;
		double minimo =0;


		double valore = 0;

		if(type==2){
			if (Collection != null && Collection.size() != 0) {
				int i = 0;

				Iterator<?> it = Collection.iterator();
				while (it.hasNext()) {
					Pressione pre = (Pressione) it.next();
					double prov    = (double) pre.getbar();
					valore = valore + (double) pre.getbar();
					tocalc[i] = prov;
					i++;

				}

				massimo = tocalc[0];
				minimo = tocalc[0];

				for(i=0;i<tocalc.length-1;i++) {

					if(massimo<tocalc[i+1])
						massimo = tocalc[i+1];
					if(minimo>tocalc[i+1])
						minimo = tocalc[i+1];
				}

				media = valore/Collection.size();
			}

		} else if(type==3){

			if (Collection != null && Collection.size() != 0) {
				Iterator<?> it = Collection.iterator();
				int i = 0;
				while (it.hasNext()) {
					Temperatura tem = (Temperatura) it.next();
					double prov    = (double) tem.getGradiCentigradi();
					valore = valore + (double) tem.getGradiCentigradi();
					tocalc[i] = prov;

					i++;

				}
				massimo = tocalc[0];
				minimo = tocalc[0];

				for(i=0;i<tocalc.length-1;i++) {

					if(massimo<tocalc[i+1])
						massimo = tocalc[i+1];
					if(minimo>tocalc[i+1])
						minimo = tocalc[i+1];
				}

				media = valore/Collection.size();


			}

		}

		valori[0] = media;
		valori[1] = minimo;
		valori[2] = massimo;


		return valori;
	}

	/**
	 * 
	 * Funzione di Ottenimento dello Storico dei Dati di un Sensore, mediante funzione DAO.
	 * 
	 * @param idLoc								Identificativo della localita' di interesse.
	 * @param tipo								Specializzazione (il Tipo) del Sensore.
	 * @param datain							Data da cui iniziare ad elaborare lo Storico.
	 * @param fine								Data in cui termina lo Storico.
	 * @return 									Ritorno del vettore dello storico dei dati.
	 * @throws SQLException						Lancia Eccezioni riguardanti la gestione della Base Dati.
	 * 
	 */

	@Override
	public Collection<Object> getHistory(int idLoc,int tipo, String datain, String fine) throws SQLException {
		return dao.SensoreDAO.readSensorData(idLoc, tipo, datain, fine);
	}

	/**
	 * 
	 * Funzione di Aggiunta Localita' Preferiti, mediante funzione DAO.
	 * 
	 * @param idLoc						ID del Sensore.
	 * @param email						Email associata all'Utente Registrato. 
	 * @return							Restituisce un Boolean: Vero (Aggiunto) - Falso (Non Aggiunto).
	 * @throws SQLException				Lancia Eccezioni riguardanti la gestione della Base Dati.
	 * 
	 */

	@Override
	public boolean addFavourite(int idLoc, String email) throws SQLException {
		return dao.OspiteRegistratoDAO.addFavourite(idLoc, email);
	}

	/**
	 * 
	 * Funzione per Mostrare le Localita' Preferite aggiunte, mediante funzione DAO.
	 * 
	 * @param email						Email associata all'Utente Registrato.
	 * @return							Ritorna le Localita' aggiunte ai Preferiti.
	 * @throws SQLException				Lancia Eccezioni riguardanti la gestione della Base Dati.
	 * 
	 */

	@Override
	public Collection<Localita> getFavourites(String email) throws SQLException {
		// TODO
		return null;
	}

	/**
	 * 
	 * Funzione per rimuovere le Localita' dai Preferiti aggiunti, mediante funzione DAO.
	 * 
	 * @param idLoc						ID della Localita' che si intende rimuovere dai preferiti.
	 * @throws SQLException				Lancia Eccezioni riguardanti la gestione della Base Dati.
	 * 
	 */

	@Override
	public void destroyFavourite(int idLoc) throws SQLException {
		// TODO
	}

	/**
	 * 
	 * Funzione per Mostrare i Dati Personali dell'Ospite Registrato, mediante funzione DAO.
	 * 
	 * @param email						Email associata all'Utente registrato.
	 * @return							Ritorna l'Utente Registrato, tramite cui � poossibile accedere ai vari dati personali.
	 * @throws SQLException				Lancia Eccezioni riguardanti la gestione della Base Dati.
	 * 
	 */

	@Override
	public OspiteRegistrato showPersonalData(String email) throws SQLException {
		// TODO
		return null;
	}

}
