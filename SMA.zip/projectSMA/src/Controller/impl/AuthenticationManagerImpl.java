package Controller.impl;

import java.sql.SQLException;

import Controller.AuthenticationManager;
import entity.OspiteRegistrato;

/**
 * 
 * Controllore dell'Accesso al Sistema (login e logout) con implementazioni delle funzioni DAO.
 * 
 * @author L. Arena, F. Caltabiano, V. D'Ambrosio, B. De Carlo
 *
 */

public class AuthenticationManagerImpl implements AuthenticationManager{

	/**
	 * 
	 * Funzione di login nel Sistema, mediante funzione DAO.
	 * 
	 */
	
	public OspiteRegistrato login(String username, String password)  {

		try {
			return dao.OspiteRegistratoDAO.readOspiteRegistrato(username, password);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public void logout(String email) {
		
	}

}
