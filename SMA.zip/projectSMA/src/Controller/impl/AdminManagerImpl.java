package Controller.impl;

//import Controller.SMA_EIS;

import java.sql.SQLException;
import java.util.Collection;
import java.util.Iterator;
import Controller.AdminManager;
import entity.Sensore;

/**
 * 
 * La classe permette l'implementazione delle funzioni DAO relative ai sensori.
 * 
 * @author L. Arena, F. Caltabiano, V. D'Ambrosio, B. De Carlo
 * 
 */

public class AdminManagerImpl implements AdminManager {
	
	/**
	 * 
	 * Richiama la funzione necessaria per l'aggiunta di un nuovo sensore all'interno del database.
	 * 
	 * @param sensore						Sensore che si desidera aggiungere.
	 * @throws SQLException					Lancia le eccezione della Base di Dati.
	 * 
	 */
	
	@Override
	public void addSensor(Sensore sensore) throws SQLException {

		dao.SensoreDAO.create(sensore);
	}
	
	/**
	 * 
	 * Richiama update della classe SensoreDAO cambiandone lo stato.
	 * 
	 * @param sensore						Sensore che si ddesidera aggiornare.
	 * @throws SQLException					Lancia le eccezione della Base di Dati.
	 * 
	 */
	
	@Override
	public void updateSensor(Sensore sensore) throws SQLException {
		if(getStatus(sensore.getIdentificativo()) == true) {
			sensore.setStatus(false);
		} else if(getStatus(sensore.getIdentificativo()) == false) {
			sensore.setStatus(true);
		}
		dao.SensoreDAO.update(sensore);
	}

	/**
	 * 
	 * Richiama la funzione necessaria alla rimozione del sensore selezionato.
	 * 
	 * @param idsens						Sensore che si desidera rimuovere.
	 * @throws SQLException					Lancia le eccezione della Base di Dati.
	 * 
	 */
	
	@Override
	public void removeSensor(int idsens) throws SQLException {

		dao.SensoreDAO.delete(idsens);
	}
	
	/**
	 * 
	 * Richiama la funzione del DAO readListasensori utilizzando l'ID della localita' e calcolando la dimensione del vettore di ritorno.
	 * 
	 * @param idLoc							Localita' sulla quale si desidera visualizzare il numero dei sensori.
	 * @return								Restituisce il numero dei sensori nella localita'.
	 * @throws SQLException					Lancia le eccezione della Base di Dati.
	 * 
	 */
	
	@Override
	public int numeroSensori(int idLoc) throws SQLException {

		return dao.SensoreDAO.readListaSensori(idLoc).size();

	}
	
	/**
	 * 
	 * Richiama la funzione readlista sensori utilizzando la localita'.
	 * 
	 * @param idLoc							Localita' sulla quale si desidera fare la ricerca.
	 * @return								Restituisce il vettore di sensori appartenenti alla data localita'.
	 * @throws SQLException					Lancia le eccezione della Base di Dati.
	 * 
	 */
	
	@Override
	public Collection<Object> showSensors(int idLoc) throws SQLException {

		return dao.SensoreDAO.readListaSensori (idLoc);

	}
	
	/**
	 * 
	 * Richiama la funzione readsensore prendedo lo stato del sensore specificato.
	 * 
	 * @param idSens						L'identificativo del sensore del quale si desidera controllare lo stato.
	 * @return								Ritorna lo stato del sensore.
	 * @throws SQLException					Lancia le eccezione della Base di Dati.
	 * 
	 */
	
	@Override
	public boolean getStatus(int idSens) throws SQLException {

		boolean stato = dao.SensoreDAO.readSensore(idSens).isStatus();

		return stato;
	}
	
	/**
	 * 
	 * Dato il tipo la funzione controlla se esiste un sensore nelle localita' selezionata avente il medesimo campo tipo.
	 *
	 * @param idLoc							Localita' sulla quale si desidera vusializzare se il tipo � gi� presente.
	 * @param tipoSens						Il tipo del sensore che si desidera controllare.
	 * @return								Resistuisce il sensore trovato.
	 * @throws SQLException					Lancia le eccezione della Base di Dati.
	 * 
	 */

	@Override
	public Sensore tipoPresente(int idLoc, int tipoSens) throws SQLException {

		Collection<?> SensL = showSensors(idLoc);
		if (SensL != null && SensL.size() != 0) {
			Iterator<?> it = SensL.iterator();
			while (it.hasNext()) {
				Sensore sens = (Sensore) it.next();   

				if(sens.getTipo() == tipoSens) {
					return sens;
				}
			}
		}
		
		Sensore sens = new Sensore();
		sens.setIdentificativo(0);
		return sens ;
	}
	
}


