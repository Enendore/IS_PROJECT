package Controller.impl;

import Controller.*;

/**
 * 
 * Estensione della classe controllore SMA_EIS.
 * 
 * @author L. Arena, F. Caltabiano, V. D'Ambrosio, B. De Carlo
 *
 */

public class DefaultSMA_EISBuilder extends SMA_EIS.SMA_EISBuilder {

	/**
	 * 
	 * Costruttore della classe SMA_EIS.
	 * 
	 * @return super.build()                    Ritorna un istanza di SMA_EIS.
	 * 
	 */

	@Override
	public SMA_EIS build() {
		AuthenticationManager ORManager  = new AuthenticationManagerImpl();
		GuestManager OManager = new GuestManagerImpl();
		AdminManager AManager = new AdminManagerImpl();

		return super.build(ORManager, AManager, OManager);
	}

}