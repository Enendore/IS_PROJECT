package Controller;

import java.sql.SQLException;
import java.util.Collection;

import entity.*;

/**
 * 
 * Controllore AdminManager, contenente le firme delle funzioni utilizzate.
 * 
 * @author L. Arena, F. Caltabiano, V. D'Ambrosio, B. De Carlo
 * 
 */

public interface  AdminManager {

	/**
	 * 
	 * Firma della funzione addSensor
	 * 
	 * @param sensore						Sensore che si desidera aggiungere.
	 * @throws SQLException					Lancia le eccezione della Base di Dati.
	 * 
	 */
	
	public void addSensor(Sensore sensore) throws SQLException; 

	/**
	 * 
	 * Firma della funzione updateSensor
	 * 
	 * @param sensore						Sensore che si ddesidera aggiornare.
	 * @throws SQLException					Lancia le eccezione della Base di Dati.
	 * 
	 */
	
	public void updateSensor(Sensore sensore) throws SQLException;

	/**
	 * 
	 * Firma della funzione removeSensor.
	 * 
	 * @param idsens						Sensore che si desidera rimuovere.
	 * @throws SQLException					Lancia le eccezione della Base di Dati.
	 * 
	 */
	
	public void removeSensor(int idsens) throws SQLException;

	/**
	 * 
	 * Firma della funzione numeroSensori.
	 * 
	 * 	
	 * @param idLoc							Localita' che sulla quale si desidera visualizzare il numero dei sensori.
	 * @return								Restituisce il numero dei sensori nella localita'.
	 * @throws SQLException					Lancia le eccezione della Base di Dati.
	 * 
	 */
	
	public int numeroSensori(int idLoc) throws SQLException;

	/**
	 * 
	 * Firma della funzione tipoPresente.
	 * 
	 * @param idLoc							Localita' sulla quale si desidera vusializzare se il tipo � gi� presente.
	 * @param tipoSens						Il tipo del sensore che si desidera controllare.
	 * @return								Resistuisce il sensore trovato.
	 * @throws SQLException					Lancia le eccezione della Base di Dati.
	 * 
	 */
	
	public Sensore tipoPresente(int idLoc, int tipoSens) throws SQLException;

	/**
	 * 
	 * Firma della funzione getStatus.
	 * 	
	 * @param idSens						L'identificativo del sensore del quale si desidera controllare lo stato.
	 * @return								Ritorna lo stato del sensore.
	 * @throws SQLException					Lancia le eccezione della Base di Dati
	 * 
	 */
	
	public boolean getStatus(int idSens) throws SQLException;

	/**
	 * 
	 * Firma della funzione showSensors.
	 * 
	 * @param idLoc							Localita' sulla quale si desidera fare la ricerca.
	 * @return								Vettore di sensori appartenenti alla data localita'.
	 * @throws SQLException					Lancia le eccezione della Base di Dati.
	 * 
	 */
	
	public Collection<Object>  showSensors(int idLoc) throws SQLException;
	
}
