package Controller;

import entity.OspiteRegistrato;

/**
 * 
 * Controllore AuthenticationManager, contenente le firme delle funzioni utilizzate.
 * 
 * @author L. Arena, F. Caltabiano, V. D'Ambrosio, B. De Carlo
 *
 */

public interface AuthenticationManager {

	/**
	 * 
	 * Firma della funzione di login.
	 * 
	 * @param username						Nomeutente (username) dell'Ospite Registrato.
	 * @param password						Password associata all'username dell'Ospite Registrato.
	 * @return								Istanza di Ospite Registrato.
	 * 
	 */
	
	public OspiteRegistrato login(String username, String password);
	
	/**
	 * 
	 * Firma della funzione di logout.
	 * 	
	 * @param email							email associata all'Utente Registrato al momento della registrazione.
	 * 
	 */
	
	public void logout(String email);

}






