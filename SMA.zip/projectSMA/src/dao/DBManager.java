package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * 
 * Permette la Comunicazione con la Base Dati.
 * 
 * @author L. Arena, F. Caltabiano, V. D'Ambrosio, B. De Carlo
 *
 */

public class DBManager {

	protected final static String dbPath = "~/gg";
	protected final static String url = "jdbc:h2:tcp://localhost/" + dbPath;

	protected static Connection conn;

	/**
	 * 
	 * Effettua la Connessione con la Base Dati.
	 * 
	 * @return	conn					Ritorna l'esito della Connessione.
	 * 
	 */
	
	public static Connection getConnection(){
		if (conn == null){
			try {
				conn = DriverManager.getConnection(url, "sa", "");
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		return conn;
	}

	/**
	 * 
	 * Effettua la Disconnessione dalla Base Dati..
	 * 
	 * @throws SQLException				Lancia Eccezioni riguardanti la gestione della Base Dati.
	 * 
	 */
	
	public static void closeConnection() throws SQLException{
		if (conn != null){
			conn.close();
			conn = null;
		}
	}

}
