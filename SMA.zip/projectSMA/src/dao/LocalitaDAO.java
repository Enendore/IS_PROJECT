package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collection;
import java.util.LinkedList;


import entity.*;

/**
 * 
 * Contiene i Data Access Object inerenti le Localita'.
 * 
 * @author L. Arena, F. Caltabiano, V. D'Ambrosio, B. De Carlo
 *
 */

public class LocalitaDAO {

	/**
	 * 
	 * Funzione per la Creazione di una nuova Localita' nella Base Dati.
	 * 
	 * @param loc						Localita'
	 * @throws SQLException				Lancia Eccezioni riguardanti la gestione della Base Dati.
	 * 
	 */

	public static void create (Localita loc) throws SQLException  {    //identificativo autoincrementante non bisogna crearlo e inserirlo da qua
		Connection connection = null;
		PreparedStatement preparedStatement = null;

		System.out.println("Sto creando una nuova localita /n" + loc.toString());

		String insertSQL ="INSERT INTO SMAdb.LOCALITA  (nomecitta, coordinategps, cap) VALUES ( ?, ?, ?)";
		try {
			connection = DBManager.getConnection();
			preparedStatement = connection.prepareStatement(insertSQL);


			preparedStatement.setString(1, loc.getNomeCitta());
			preparedStatement.setString(2, loc.getCoordinateGPS());
			preparedStatement.setInt(3, loc.getCAP());

			preparedStatement.executeUpdate();
			connection.commit();
		}
		catch (SQLException e) {
			System.out.println("C'è stato un errore nella creazione della localita /n" + loc.toString()); 
		}

	}

	/**
	 * 
	 * Funzione di Modifica ed aggiornamento di una Localita' nella Base Dati.
	 * 
	 * @param loc						Localita'
	 * @throws SQLException				Lancia Eccezioni riguardanti la gestione della Base Dati.
	 * 
	 */

	public static void update (Localita loc) throws SQLException { 

		Connection connection = null;
		PreparedStatement preparedStatement = null;

		System.out.println("Sto modificando una localit� /n" + loc.toString());

		String insertSQL ="UPDATE SMAdb.LOCALITA SET nomecitta=?, coordinategps=?, cap=? WHERE idLoc = ?";
		try {
			connection = DBManager.getConnection();
			preparedStatement = connection.prepareStatement(insertSQL);


			preparedStatement.setString(1, loc.getNomeCitta());
			preparedStatement.setString(2, loc.getCoordinateGPS());
			preparedStatement.setInt(3, loc.getCAP());
			preparedStatement.setInt(4, loc.getIdLoc());

			preparedStatement.executeUpdate();
			connection.commit();
		}
		catch (SQLException e) {
			System.out.println("C'� stato un errore nella modifica della localita /n" + loc.toString()); 
		}

	}

	/**
	 * 
	 * Funzione di Lettura di una Localita' scelta, dalla Base Dati.
	 * 
	 * @param idLocalita				ID della Localita'.
	 * @return							Ritorna la Localita'.
	 * @throws SQLException				Lancia Eccezioni riguardanti la gestione della Base Dati.
	 * 
	 */

	public static Localita readLocalita (int idLocalita) throws SQLException {  //forse � inutile? la ricerca del posto dovrebbe dare direttamente i sensori..


		Connection connection = null;
		PreparedStatement preparedStatement = null;


		System.out.println("Sto cercando una localita con idLocalita" + idLocalita );

		Localita loc = new Localita();
		String selectSQL = "SELECT * FROM SMADB.localita  WHERE IDLOC =?";

		try {
			connection = DBManager.getConnection();
			preparedStatement = connection.prepareStatement(selectSQL);
			preparedStatement.setInt(1, idLocalita);

			ResultSet rs = preparedStatement.executeQuery();

			while (rs.next()) {

				loc.setCAP(rs.getInt("CAP"));
				loc.setIdLoc(rs.getInt("IDLOCALITA"));
				loc.setNomeCitta(rs.getString("NOMECITTA"));
				loc.setCoordinateGPS(rs.getString("COORDINATEGPS"));

			}

			return loc;

		}  catch (SQLException e) {
			System.out.println("C'è stato un errore nella visualizzazione della localita /n"); 
			return null;

		}


	}

	/**
	 * 
	 * Funzione di Lettura dalla Base Dati, delle Localita' associate al CAP di interesse.
	 * 
	 * @param CAP						CAP di interesse.
	 * @return							Vettore di Localita' associate al CAP.
	 * @throws SQLException				Lancia Eccezioni riguardanti la gestione della Base Dati.
	 * 
	 */

	public static Collection<Localita> readListaLocalita (int CAP) throws SQLException  {

		Connection connection = null;
		PreparedStatement preparedStatement = null;
		Collection<Localita> objects = new LinkedList<Localita>();

		System.out.println("Sto cercando le localita \n");

		String selectSQL = "SELECT * FROM SMADB.LOCALITA  WHERE CAP =? ";

		try {
			connection = DBManager.getConnection();
			preparedStatement = connection.prepareStatement(selectSQL);
			preparedStatement.setInt(1, CAP);

			ResultSet rs = preparedStatement.executeQuery();

			while (rs.next()) {

				Localita loc = new Localita();

				loc.setCAP(rs.getInt("CAP"));
				loc.setIdLoc(rs.getInt("IDLOC"));
				loc.setNomeCitta(rs.getString("NOMECITTA"));
				loc.setCoordinateGPS(rs.getString("COORDINATEGPS"));

				objects.add(loc);

			}

		}  catch (SQLException e) {
			System.out.println("C'è stato un errore nella visualizzazione della lista di localita \n"); 
			System.out.println(e);
			return null;
		}
		return objects;
	}
}

