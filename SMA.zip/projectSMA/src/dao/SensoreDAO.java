package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collection;
import java.util.LinkedList;
import java.sql.Date;


import entity.*;

/**
 * 
 * Contiene i Data Access Object inerenti li Sensori.
 * 
 * @author L. Arena, F. Caltabiano, V. D'Ambrosio, B. De Carlo
 *
 */

public class SensoreDAO  {

	/**
	 * 
	 * Funzione per la Creazione di un Sensore nella Base Dati.
	 * 
	 * @param s							Sensore da inserire nella Base Dati.
	 * @throws SQLException				Lancia Eccezioni riguardanti la gestione della Base Dati.
	 * 
	 */

	public static void create (Sensore s)  throws SQLException  {    //identificativo autoincrementante non bisogna crearlo e inserirlo da qua
		Connection connection = null;
		PreparedStatement preparedStatement = null;

		System.out.println("Sto creando un nuovo sensore \n" + s.toString());

		String insertSQL ="INSERT INTO SMADB.SENSORE  (identificativo, marca, tipo, idLocalita, status) VALUES ( ?, ?, ?, ?, ?)";
		try {
			connection = DBManager.getConnection();
			preparedStatement = connection.prepareStatement(insertSQL);

			preparedStatement.setInt(1, s.getIdentificativo());
			preparedStatement.setString(2, s.getMarca());
			preparedStatement.setInt(3, s.getTipo());
			preparedStatement.setInt(4, s.getIdLocalita());
			preparedStatement.setBoolean(5, s.isStatus());


			preparedStatement.executeUpdate();
			connection.commit();
		}
		catch (SQLException e) {
			System.out.println("C'e' stato un errore nella creazione del sensore \n" + s.toString()); 
		}

	}

	/**
	 * 
	 * Funzione per commutaree lo Stato di un Sensore (lo "Aggiorna") all'interno della Base Dati.
	 * 
	 * @param s							Sensore da aggiornare.
	 * @throws SQLException				Lancia Eccezioni riguardanti la gestione della Base Dati.
	 * 
	 */

	public static void update (Sensore s) throws SQLException { 

		Connection connection = null;
		PreparedStatement preparedStatement = null;

		System.out.println("Sto modificando un sensore \n" + s.toString());

		String insertSQL ="UPDATE SMADB.SENSORE SET status=? WHERE identificativo = ?";
		try {
			connection = DBManager.getConnection();
			preparedStatement = connection.prepareStatement(insertSQL);


			preparedStatement.setBoolean(1, s.isStatus());
			preparedStatement.setInt(2,s.getIdentificativo());
			preparedStatement.executeUpdate();
			connection.commit();
		}
		catch (SQLException e) {
			System.out.println("C'E' STATO UN ERRORE NEL CAMBIO DELLO STATO DEL SENSORE \n\n" + s.toString()); 
		}

	}

	/**
	 * 
	 * Funzione per la cancellazione di un sensore dalla Base Dati.
	 * 
	 * @param idSens					ID del Sensore.
	 * @return							Ritorna l'esito della cancellazione (sottoforma di intero).
	 * @throws SQLException				Lancia Eccezioni riguardanti la gestione della Base Dati.
	 * 
	 */

	public static int delete(int idSens)  throws SQLException  {

		Connection connection = null;
		PreparedStatement preparedStatement = null;
		int result = 0;

		String deleteSQL = "DELETE FROM  SMADB.SENSORE  WHERE IDENTIFICATIVO = ? ";

		try {
			connection = DBManager.getConnection();
			preparedStatement = connection.prepareStatement(deleteSQL);
			preparedStatement.setInt(1, idSens);

			result = preparedStatement.executeUpdate();

		} catch (SQLException e) {
			System.out.println("C'e' stato un errore nell'eliminazione del sensore \n"); 
		}

		return result;

	}

	/**
	 * 
	 * Funzione che permette di leggere i Sensori associati ad una data Localita'.
	 * 
	 * @param idLocalita				ID della Localita'.
	 * @return							Vettore di Sensori associati alla Localita'.
	 * @throws SQLException				Lancia Eccezioni riguardanti la gestione della Base Dati.
	 * 
	 */

	public static Collection<Object>  readListaSensori (int idLocalita)   throws SQLException  {

		Connection connection = null;
		PreparedStatement preparedStatement = null;
		Collection<Object> objects = new LinkedList<Object>();

		System.out.println("Sto cercando i sensori");

		String selectSQL = "SELECT * FROM SMADB.SENSORE  WHERE IDLOCALITA =? ";

		try {
			connection = DBManager.getConnection();
			preparedStatement = connection.prepareStatement(selectSQL);
			preparedStatement.setInt(1, idLocalita);

			ResultSet rs = preparedStatement.executeQuery();

			while (rs.next()) {

				Sensore se = new Sensore();

				se.setIdentificativo(rs.getInt("IDENTIFICATIVO"));
				se.setIdLocalita(rs.getInt("IDLOCALITA"));
				se.setMarca(rs.getString("MARCA"));
				se.setStatus(rs.getBoolean("STATUS"));
				se.setTipo(rs.getInt("TIPO"));





				objects.add(se);


			}

			return objects;

		}  catch (SQLException e) {
			System.out.println("C'e' stato un errore nella recupero dei sensori \n"); 
			return null;

		}

	}

	/**
	 * 
	 * Funzione che permette di accedere ai Dati di uno Specifico Sensore dalla Base Dati.
	 * 
	 * @param identificativo			ID del Sensore.
	 * @param tipo						Tipo del Sensore.
	 * @return							Ritorna i Dati letti nel sensore.
	 * @throws SQLException				Lancia Eccezioni riguardanti la gestione della Base Dati.
	 * 
	 */

	public static Object readData (int identificativo, int tipo)  throws SQLException {

		Connection connection = null;
		PreparedStatement preparedStatement = null;
		String esegui="";
		String valore="";
		Vento ven = new Vento();
		Pressione pre = new Pressione();
		Temperatura temp = new Temperatura();
		Umidita umi = new Umidita();



		String VselectSQL = "SELECT * FROM SMADB.VENTO  WHERE IDENTIFICATIVO = ?   ";
		String PselectSQL = "SELECT * FROM SMADB.PRESSIONE  WHERE IDENTIFICATIVO = ?  ";
		String TselectSQL = "SELECT * FROM SMADB.TEMPERATURA WHERE IDENTIFICATIVO = ? ";		
		String UselectSQL = "SELECT * FROM SMADB.UMIDITA  WHERE IDENTIFICATIVO =? ";

		//		


		if(tipo==1) {
			esegui=VselectSQL;
			valore="KMH";
		}
		else  if(tipo==2){
			esegui=PselectSQL;
			valore="BAR";
		}
		else if(tipo==3){
			esegui=TselectSQL;
			valore="GRADICENTIGRADI";	
		}
		else if(tipo==4){
			esegui=UselectSQL;
			valore="PERCENTUALE";	
		}

		try {
			connection = DBManager.getConnection();
			preparedStatement = connection.prepareStatement(esegui);
			preparedStatement.setInt(1, identificativo);


			ResultSet rs = preparedStatement.executeQuery();


			if(tipo==1) {
				while (rs.next()) {
					ven.setIdentificativo(rs.getInt("IDENTIFICATIVO"));
					String dirfa =  (rs.getString(valore)+rs.getString("DIREZIONE"));
					ven.setDir_vel(dirfa);
					ven.setData(rs.getDate("DATA"));	
					ven.setOra(Integer.parseInt(rs.getString("DATA").substring(11,13)));
					ven.setMinuti(Integer.parseInt(rs.getString("DATA").substring(14,16)));
				}

				return ven;	
			}	
			else if(tipo==2){
				while (rs.next()) {
					pre.setIdentificativo(rs.getInt("IDENTIFICATIVO"));
					pre.setbar(rs.getInt(valore));
					pre.setData(rs.getDate("DATA"));	
					pre.setOra(Integer.parseInt(rs.getString("DATA").substring(11,13)));
					pre.setMinuti(Integer.parseInt(rs.getString("DATA").substring(14,16)));

				}
				return pre;
			}
			else if(tipo==3){
				while (rs.next()) {
					temp.setIdentificativo(rs.getInt("IDENTIFICATIVO"));
					temp.setGradiCentigradi(rs.getFloat(valore));
					temp.setData(rs.getDate("DATA"));				
					temp.setOra(Integer.parseInt(rs.getString("DATA").substring(11,13)));
					temp.setMinuti(Integer.parseInt(rs.getString("DATA").substring(14,16)));
				}
				return temp;

			}
			else if(tipo==4){
				while (rs.next()) {
					umi.setIdentificativo(rs.getInt("IDENTIFICATIVO"));
					umi.setpercentuale(rs.getInt(valore));	
					umi.setData(rs.getDate("DATA"));		
					umi.setOra(Integer.parseInt(rs.getString("DATA").substring(11,13)));
					umi.setMinuti(Integer.parseInt(rs.getString("DATA").substring(14,16)));

				}
				return umi;
			}



		}  catch (SQLException e) {
			System.out.println("C'e' stato un errore nel recupero del sensore \n"); 
			System.out.println(e);

		}
		return null;

	}

	/**
	 * 
	 * Funzione che permette di Leggere le Informazioni del Sensore dalla Base Dati.
	 * 
	 * @param identificativo			ID del Sensore.
	 * @return							Restituisce un'Istanza del Sensore.
	 * @throws SQLException				Lancia Eccezioni riguardanti la gestione della Base Dati.
	 * 
	 */

	public static Sensore readSensore ( int identificativo )  throws SQLException {

		Connection connection = null;
		PreparedStatement preparedStatement = null;



		Sensore se = new Sensore();
		String selectSQL = "SELECT * FROM smadb.SENSORE  WHERE IDENTIFICATIVO =?  ";

		try {
			connection = DBManager.getConnection();
			preparedStatement = connection.prepareStatement(selectSQL);
			preparedStatement.setInt(1, identificativo);


			ResultSet rs = preparedStatement.executeQuery();

			while (rs.next()) {
				se.setIdentificativo(rs.getInt("IDENTIFICATIVO"));
				se.setIdLocalita(rs.getInt("IDLOCALITA"));
				se.setMarca(rs.getString("MARCA"));
				se.setStatus(rs.getBoolean("STATUS"));
				se.setTipo(rs.getInt("TIPO"));

			}

			return se;

		}  catch (SQLException e) {
			System.out.println("C'� stato un errore nella recupero del sensore \n"); 
			return null;

		}

	}

	/**
	 * 
	 * Funzione che riporta i valori del Sensore in un Dato intervallo di Tempo dalla Base Dati.
	 * 
	 * @param identificativo			ID del Sensore.
	 * @param tipo						Specializzazione del Senzore.
	 * @param datin						Inizio Intervallo Temporale.
	 * @param fine						Fine Intervallo Temporale.
	 * @return							Ritorna un Vettore di Dati del Sensore.
	 * @throws SQLException				Lancia Eccezioni riguardanti la gestione della Base Dati.
	 * 
	 */
	
	public static Collection<Object> readSensorData (int identificativo, int tipo, String datin, String fine)  throws SQLException {

		Connection connection = null; 
		PreparedStatement preparedStatement = null;
		String esegui="";
		String valore="";
		Collection<Object> cosen = new LinkedList<Object>();


		String PselectSQL = "SELECT * FROM SMADB.PRESSIONE  WHERE IDENTIFICATIVO = ? and data BETWEEN ? and  ?";
		String TselectSQL = "SELECT * FROM SMADB.TEMPERATURA WHERE IDENTIFICATIVO = ? and data BETWEEN ? and ?";		

		System.out.println("Ecco i dati del sensore\n");



		if(tipo==2){
			esegui=PselectSQL;
			valore="BAR";
		}
		else if(tipo==3){
			esegui=TselectSQL;
			valore="GRADICENTIGRADI";	
		}


		try {
			connection = DBManager.getConnection();
			preparedStatement = connection.prepareStatement(esegui);
			preparedStatement.setInt(1, identificativo);

			Date datain = Date.valueOf(datin);
			Date datend = Date.valueOf(fine);


			preparedStatement.setDate(2,datain);
			preparedStatement.setDate(3, datend);


			ResultSet rs = preparedStatement.executeQuery();


			if(tipo==2){

				while (rs.next()) {
					Pressione pre = new Pressione();

					pre.setIdentificativo(rs.getInt("IDENTIFICATIVO"));
					pre.setbar(rs.getInt(valore));
					pre.setData(rs.getDate("DATA"));	
					pre.setOra(Integer.parseInt(rs.getString("DATA").substring(11,13)));
					pre.setMinuti(00);

					cosen.add(pre);				

				}
				return cosen;

			}
			else if(tipo==3){
				while (rs.next()) {

					Temperatura temp = new Temperatura();


					temp.setIdentificativo(rs.getInt("IDENTIFICATIVO"));
					temp.setGradiCentigradi(rs.getFloat(valore));
					temp.setData(rs.getDate("DATA"));				
					temp.setOra(Integer.parseInt(rs.getString("DATA").substring(11,13)));
					temp.setMinuti(00);
					cosen.add(temp);

				}
				return cosen;
			}


		}  catch (SQLException e) {
			System.out.println("C'e' stato un errore nella creazione del sensore /n"); 
			System.out.println(e); 
		}
		return null;

	}

}


