package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import entity.*;

/**
 * 
 * Contiene i Data Access Object inerenti l'Ospite Registrato.
 * 
 * @author L. Arena, F. Caltabiano, V. D'Ambrosio, B. De Carlo
 * 
 */

public class OspiteRegistratoDAO {

	/**
	 * 
	 * Funzione per la Creazione di un Utente Registrato all'interno della Base Dati.
	 * 
	 * @param or						Istanza di Ospite Registrato.
	 * @return							Ritorna l'esito della Creazione.
	 * @throws SQLException				Lancia Eccezioni riguardanti la gestione della Base Dati.
	 * 
	 */

	public static boolean create ( OspiteRegistrato or) throws SQLException  {

		Connection connection = null;
		PreparedStatement preparedStatement = null;

		System.out.println("Registrazione in corso...  \n" );

		String insertSQL ="INSERT INTO SMAdb.OspiteRegistrato  (email, username, password) VALUES ( ?, ?, ?)";
		try {
			connection = DBManager.getConnection();
			preparedStatement = connection.prepareStatement(insertSQL);


			preparedStatement.setString(1, or.getEmail());
			preparedStatement.setString(2, or.getUsername());
			preparedStatement.setString(3, or.getPassword());


			preparedStatement.executeUpdate();
			connection.commit();

			return true;
		}
		catch (SQLException e) {
			System.out.println("C'� stato un errore nella creazione dell'utente \n" ); 
			return true;

		}

	}

	/**
	 * 
	 * Funzione per l'aggiunta di una Localita' ai Preferiti, all'interno della Base Dati.
	 * 
	 * @param idLoc						ID della Localita'.
	 * @param email						Email associata all'Ospute Registrato in fase di Registrazione.
	 * @return							Ritorna l'esito dell'aggiunta ai preferiti.
	 * @throws SQLException				Lancia Eccezioni riguardanti la gestione della Base Dati.
	 */

	public static boolean addFavourite(int idLoc, String email) throws SQLException  {
		Connection connection = null;
		PreparedStatement preparedStatement = null;

		System.out.println("Aggiunta in corso...  \n" );

		String insertSQL ="INSERT INTO SMAdb.PREFERITO  (idlocalita, email) VALUES ( ?, ?)";
		try {
			connection = DBManager.getConnection();
			preparedStatement = connection.prepareStatement(insertSQL);


			preparedStatement.setInt(1, idLoc);
			preparedStatement.setString(2, email);



			preparedStatement.executeUpdate();
			connection.commit();


			System.out.println("Aggiunta con successo!  \n" );


		}
		catch (SQLException e) {

			System.out.println("C'� stato un errore nell'aggiunta ai preferiti! \n\n" ); 
			return false;
		}




		return true;
	}

	/**
	 * 
	 * Funzione per la lettura delle informazioni associate all'Ospite Registrato dalla Base Dati.
	 * 
	 * @param user						Username associata all'Ospite Registrato in fase di Registrazione.
	 * @param password					Password associata all'Ospite Registrato in fase di Registrazione.
	 * @return							Ritorna un'istanza di Ospite Registarto.
	 * @throws SQLException				Lancia Eccezioni riguardanti la gestione della Base Dati.
	 * 
	 */

	public static OspiteRegistrato readOspiteRegistrato(String user, String password) throws SQLException {

		Connection connection = null;
		PreparedStatement preparedStatement = null;

		System.out.println("Sto recuperando i tuoi dati...\n" );

		OspiteRegistrato or = new OspiteRegistrato();


		String selectSQL = "SELECT * FROM SMAdb.OspiteRegistrato  WHERE username =? and password=? ";

		try {
			connection = DBManager.getConnection();
			preparedStatement = connection.prepareStatement(selectSQL);
			preparedStatement.setString(1, user);
			preparedStatement.setString(2, password);


			ResultSet rs = preparedStatement.executeQuery();

			while (rs.next()) {
				if (!rs.getString("USERNAME").equals("")){
					or.setUsername(rs.getString("USERNAME"));
					or.setEmail(rs.getString("EMAIL"));
					or.setPassword(rs.getString("PASSWORD"));
				} else or = null;

			}

			return or;

		}  catch (SQLException e) {
			System.out.println("C'� stato un errore nel recupero dati ospite /n"); 
			return null;

		}


	}

}