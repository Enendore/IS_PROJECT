package test;

/**
 * 
 * Sottoclasse di Exception, permette la gestione di Errori dovuti in Fase di Testing.
 * 
 * @author L. Arena, F. Caltabiano, V. D'Ambrosio, B. De Carlo
 *
 */

public class NotSingleException extends Exception {

	/**
	 * 
	 * Identificativo Numerico associato alla Sottoclasse NotSingleException.
	 * 
	 */
	
	private static final long serialVersionUID = -4031629272314676679L;

	/**
	 * 
	 * Costruttore di Default della Sottoclasse NotSingleException.
	 * 
	 */
	
	public NotSingleException() {
		super();
	}

	/**
	 * 
	 * Costruttore della sottoclasse NotSingleException.
	 * 
	 * @param message						Messaggio di Errore.
	 * @param cause							Causa dell'Errore.
	 * @param enableSuppression				Condizione di Arresto del Sistema.
	 * @param writableStackTrace			Condizione di Scrittura.
	 * 
	 */
	
	public NotSingleException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

	/**
	 * 
	 * Costruttore della sottoclasse NotSingleException.
	 * 
	 * @param message						Messaggio di Errore.
	 * @param cause							Causa dell'Errore.
	 * 
	 */
	
	public NotSingleException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * 
	 * Costruttore della sottoclasse NotSingleException.
	 * 
	 * @param message						Messaggio di Errore.
	 * 
	 */
	
	public NotSingleException(String message) {
		super(message);
	}

	/**
	 * 
	 * Costruttore della sottoclasse NotSingleException.
	 * 
	 * @param cause							Causa dell'Errore.
	 * 
	 */
	
	public NotSingleException(Throwable cause) {
		super(cause);
	}
	
}
