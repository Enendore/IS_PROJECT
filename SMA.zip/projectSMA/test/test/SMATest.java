package test;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.util.List;
import org.junit.After;
import org.junit.AfterClass;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import Controller.SMA_EIS;
import entity.Localita;
import entity.Sensore;

/**
 * 
 * Test delle Funzioni dell'SMA.
 * 
 * @author L. Arena, F. Caltabiano, V. D'Ambrosio, B. De Carlo
 *
 */

public class SMATest {

	/**
	 * 
	 * Costruttore di Default del Test.
	 * 
	 */
	
	public SMATest() {
	}

	private static SMA_EIS instance;

	/**
	 * 
	 * Set up della Classe SMATest.
	 * 
	 */
	
	@BeforeClass
	public static void setUpClass() {
		instance = SMA_EIS.getInstance();
		instance.login("test", "test");
	}

	/**
	 * 
	 * Tear Down della Classe SMATest.
	 * 
	 */
	
	@AfterClass
	public static void tearDownClass() {
	}

	/**
	 * 
	 * Set up.
	 * 
	 */
	
	@Before
	public void setUp() {

	}

	/**
	 * 
	 * Tear Down.
	 * 
	 */
	
	@After
	public void tearDown() {
	}

	/**
	 * 
	 * Funzione di Creazione del Sensore.
	 * 
	 * @return							Ritorna un Sensore.
	 * 
	 */
	
	private Sensore createSensore() {
		Sensore sens = new Sensore();
		sens.setIdentificativo(2);
		sens.setIdLocalita(1);
		sens.setMarca("PHILIPS");
		sens.setStatus(true);
		sens.setTipo(2); //Corrisponde a Vento

		return sens;
	}

	/**
	 * 
	 * Funzione di creazione della Localita'.
	 * 
	 * @return							Ritorna una Localita'.
	 * 			
	 */
	
	private Localita createLocalita() {
		Localita loc = new Localita();
		loc.setCAP(80040);
		loc.setCoordinateGPS("00GPS00"); 
		loc.setIdLoc(3);
		loc.setNomeCitta("Cercola");

		return loc;
	}

	/**
	 * 
	 * Ricerca della Localita' mediante ID.
	 * 
	 * @param sensorList				Lista dei Sensori.
	 * @param id						ID della Localita' selezionata.
	 * @return							Ritorna la Localita' selezionata.
	 * @throws NotSingleException		Lancio delle Eccezioni in Fase di Testing.	
	 * 
	 */
	
	private Localita selectLocationById(List<Localita> sensorList, int id) throws NotSingleException {
		if (sensorList == null) return null;

		Localita localitaToReturn = null;
		for (Localita loc : sensorList) {
			if (id == loc.getIdLoc()) {
				if (localitaToReturn == null) {
					localitaToReturn = loc;
				} else {
					throw new NotSingleException("More than one sensor with same id! Id=" + id);
				}
			}
		}
		return localitaToReturn;
	}

	/**
	 * 
	 * Test della Funzione di Ricerca della Localita'.
	 * 
	 * @throws Exception				Lancio delle Eccezioni in Fase di Testing.	
	 */
	
	@Test
	public void testSearchLocalita() throws Exception {
		Localita loc = createLocalita();

		int generatedID = loc.getIdLoc();
		assertNotNull(generatedID); // Post

		List<Localita> colloc = (List<Localita>) instance.searchLocation(loc.getCAP());

		Localita actualloc = ( Localita ) selectLocationById(colloc, generatedID);


		assertNotNull(actualloc); // Post
		assertEquals(loc.getCAP(), actualloc.getCAP());
		assertEquals(loc.getCoordinateGPS(), actualloc.getCoordinateGPS());
		assertEquals(loc.getNomeCitta(), actualloc.getNomeCitta());
		assertEquals(loc.getIdLoc(), loc.getIdLoc());
	}

	/**
	 * 
	 * Test della Funzione di Ricerca del Sensore.
	 * 
	 * @throws Exception				Lancio delle Eccezioni in Fase di Testing.	
	 * 
	 */
	
	@Test
	public void testSearchSensor() throws Exception {
		Sensore sen = createSensore();

		int generatedId = sen.getIdentificativo();
		assertNotNull(generatedId); // Post

		Sensore actualsens = instance.getSens(generatedId);

		assertNotNull(actualsens); // Post
		assertEquals(sen.getMarca(), actualsens.getMarca());
		assertEquals(sen.getTipo(), actualsens.getTipo());
		assertEquals(sen.getIdLocalita(), sen.getIdLocalita());
		assertEquals(sen.getIdentificativo(), sen.getIdentificativo());
	}

	/**
	 * 
	 * Test della Funzione di Aggiunta Sensore.
	 * 
	 * @throws Exception				Lancio delle Eccezioni in Fase di Testing.
	 * 
	 */
	
	@Test
	public void testAddSensor() throws Exception{
		Sensore sen = new Sensore();
		sen.setIdentificativo(999);
		sen.setIdLocalita(999);
		sen.setMarca("TEST");
		sen.setStatus(true);
		sen.setTipo(4);

		int generatedId = sen.getIdentificativo();
		assertNotNull(generatedId); // Post


		instance.addSensor(sen);

		Sensore actualsens = instance.getSens(sen.getIdentificativo());

		assertNotNull(actualsens); // Post
		assertEquals(sen.getIdentificativo(), actualsens.getIdentificativo());
		assertEquals(sen.getTipo(), actualsens.getTipo());
		assertEquals(sen.getIdLocalita(), sen.getIdLocalita());
		assertEquals(sen.getIdentificativo(), sen.getIdentificativo());
		instance.removeSensor(sen.getIdentificativo());
	}

	/**
	 * 
	 * Test della Funzione di Rimozione del Sensore.
	 * 
	 * @throws Exception				Lancio delle Eccezioni in Fase di Testing.
	 * 
	 */

	@Test
	public void testRemoveSensor()throws Exception {
		Sensore sen = createSensore();
		int generatedId = sen.getIdentificativo();
		assertNotNull(generatedId); // Post

		instance.removeSensor(generatedId);
		Sensore actualsens = instance.getSens(sen.getIdentificativo());
		assertNotNull(actualsens);
		assertNotEquals(actualsens, sen);
		instance.addSensor(sen);

	}

	/**
	 * 
	 * Test della Funzione di Cambio Stato del Sensore (lo "Aggiorna").
	 * 
	 * @throws Exception				Lancio delle Eccezioni in Fase di Testing.
	 * 
	 */
	
	@Test
	public void testUpdateSensor()throws Exception {
		Sensore sen = instance.getSens(1);
		boolean stato_preccedente = sen.isStatus();
		instance.updateSensor(sen);
		boolean stato_successivo = sen.isStatus();
		assertNotEquals(stato_preccedente, stato_successivo);
	}

}
